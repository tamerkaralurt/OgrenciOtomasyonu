﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiIslem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiIslem));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslblBilgiNoAdi = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dosyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çıkışToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işlemlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrenciEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenlemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.akademisyenEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenlemeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bilgiİşlemPersoneliEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bölümİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenleSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dersİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenleSilToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.harfliSistemAyarlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.düzenleToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.otomasyonAyarlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ekleToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.gboxOgrenciler = new System.Windows.Forms.GroupBox();
            this.btnRefOgr = new System.Windows.Forms.Button();
            this.lblEnYukGNO = new System.Windows.Forms.Label();
            this.lblToplamOgr = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gboxAka = new System.Windows.Forms.GroupBox();
            this.btnRefAka = new System.Windows.Forms.Button();
            this.lblToplamAka = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gboxBolumler = new System.Windows.Forms.GroupBox();
            this.btnRefBol = new System.Windows.Forms.Button();
            this.lblToplamBolum = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRefDers = new System.Windows.Forms.Button();
            this.lblToplamDers = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lboxHarfliNotlar = new System.Windows.Forms.ListBox();
            this.btnRefNotlar = new System.Windows.Forms.Button();
            this.lblToplamHarfliNotlar = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabOgrenciler = new System.Windows.Forms.TabPage();
            this.tabBolumler = new System.Windows.Forms.TabPage();
            this.tabAkademisyenler = new System.Windows.Forms.TabPage();
            this.tabDersler = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.colBolumKodu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBolumAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBolumBaskani = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.colDersKodu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDersAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDersKredi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDersBolum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDersSinif = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.gboxOgrenciler.SuspendLayout();
            this.gboxAka.SuspendLayout();
            this.gboxBolumler.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabOgrenciler.SuspendLayout();
            this.tabBolumler.SuspendLayout();
            this.tabAkademisyenler.SuspendLayout();
            this.tabDersler.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslblBilgiNoAdi});
            this.statusStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.statusStrip1.Location = new System.Drawing.Point(0, 518);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.statusStrip1.Size = new System.Drawing.Size(924, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslblBilgiNoAdi
            // 
            this.tsslblBilgiNoAdi.BackColor = System.Drawing.Color.Transparent;
            this.tsslblBilgiNoAdi.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.tsslblBilgiNoAdi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tsslblBilgiNoAdi.ForeColor = System.Drawing.Color.DimGray;
            this.tsslblBilgiNoAdi.LinkColor = System.Drawing.Color.ForestGreen;
            this.tsslblBilgiNoAdi.Name = "tsslblBilgiNoAdi";
            this.tsslblBilgiNoAdi.Size = new System.Drawing.Size(127, 17);
            this.tsslblBilgiNoAdi.Text = "toolStripStatusLabel1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaToolStripMenuItem,
            this.işlemlerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(924, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dosyaToolStripMenuItem
            // 
            this.dosyaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.çıkışToolStripMenuItem});
            this.dosyaToolStripMenuItem.Name = "dosyaToolStripMenuItem";
            this.dosyaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.dosyaToolStripMenuItem.Text = "Dosya";
            // 
            // çıkışToolStripMenuItem
            // 
            this.çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
            this.çıkışToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.çıkışToolStripMenuItem.Text = "Çıkış";
            this.çıkışToolStripMenuItem.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // işlemlerToolStripMenuItem
            // 
            this.işlemlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öğrenciEkleToolStripMenuItem,
            this.akademisyenEkleToolStripMenuItem,
            this.bilgiİşlemPersoneliEkleToolStripMenuItem,
            this.bölümİşlemleriToolStripMenuItem,
            this.dersİşlemleriToolStripMenuItem,
            this.harfliSistemAyarlarıToolStripMenuItem,
            this.otomasyonAyarlarıToolStripMenuItem});
            this.işlemlerToolStripMenuItem.Name = "işlemlerToolStripMenuItem";
            this.işlemlerToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.işlemlerToolStripMenuItem.Text = "İşlemler";
            // 
            // öğrenciEkleToolStripMenuItem
            // 
            this.öğrenciEkleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem,
            this.düzenlemeToolStripMenuItem});
            this.öğrenciEkleToolStripMenuItem.Name = "öğrenciEkleToolStripMenuItem";
            this.öğrenciEkleToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.öğrenciEkleToolStripMenuItem.Text = "Öğrenci İşlemleri";
            // 
            // ekleToolStripMenuItem
            // 
            this.ekleToolStripMenuItem.Name = "ekleToolStripMenuItem";
            this.ekleToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem.Text = "Ekle";
            this.ekleToolStripMenuItem.Click += new System.EventHandler(this.ekleToolStripMenuItem_Click);
            // 
            // düzenlemeToolStripMenuItem
            // 
            this.düzenlemeToolStripMenuItem.Name = "düzenlemeToolStripMenuItem";
            this.düzenlemeToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.düzenlemeToolStripMenuItem.Text = "Düzenle - Sil";
            this.düzenlemeToolStripMenuItem.Click += new System.EventHandler(this.düzenlemeToolStripMenuItem_Click);
            // 
            // akademisyenEkleToolStripMenuItem
            // 
            this.akademisyenEkleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem1,
            this.düzenlemeToolStripMenuItem1});
            this.akademisyenEkleToolStripMenuItem.Name = "akademisyenEkleToolStripMenuItem";
            this.akademisyenEkleToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.akademisyenEkleToolStripMenuItem.Text = "Akademisyen İşlemleri";
            // 
            // ekleToolStripMenuItem1
            // 
            this.ekleToolStripMenuItem1.Name = "ekleToolStripMenuItem1";
            this.ekleToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem1.Text = "Ekle";
            this.ekleToolStripMenuItem1.Click += new System.EventHandler(this.ekleToolStripMenuItem1_Click);
            // 
            // düzenlemeToolStripMenuItem1
            // 
            this.düzenlemeToolStripMenuItem1.Name = "düzenlemeToolStripMenuItem1";
            this.düzenlemeToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.düzenlemeToolStripMenuItem1.Text = "Düzenle - Sil";
            this.düzenlemeToolStripMenuItem1.Click += new System.EventHandler(this.düzenlemeToolStripMenuItem1_Click);
            // 
            // bilgiİşlemPersoneliEkleToolStripMenuItem
            // 
            this.bilgiİşlemPersoneliEkleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem2,
            this.düzenleToolStripMenuItem});
            this.bilgiİşlemPersoneliEkleToolStripMenuItem.Name = "bilgiİşlemPersoneliEkleToolStripMenuItem";
            this.bilgiİşlemPersoneliEkleToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bilgiİşlemPersoneliEkleToolStripMenuItem.Text = "Bilgi İşlem Personeli İşlemleri";
            // 
            // ekleToolStripMenuItem2
            // 
            this.ekleToolStripMenuItem2.Name = "ekleToolStripMenuItem2";
            this.ekleToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem2.Text = "Ekle";
            this.ekleToolStripMenuItem2.Click += new System.EventHandler(this.ekleToolStripMenuItem2_Click);
            // 
            // düzenleToolStripMenuItem
            // 
            this.düzenleToolStripMenuItem.Name = "düzenleToolStripMenuItem";
            this.düzenleToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.düzenleToolStripMenuItem.Text = "Düzenle - Sil";
            this.düzenleToolStripMenuItem.Click += new System.EventHandler(this.düzenleToolStripMenuItem_Click);
            // 
            // bölümİşlemleriToolStripMenuItem
            // 
            this.bölümİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem5,
            this.düzenleSilToolStripMenuItem});
            this.bölümİşlemleriToolStripMenuItem.Name = "bölümİşlemleriToolStripMenuItem";
            this.bölümİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bölümİşlemleriToolStripMenuItem.Text = "Bölüm İşlemleri";
            // 
            // ekleToolStripMenuItem5
            // 
            this.ekleToolStripMenuItem5.Name = "ekleToolStripMenuItem5";
            this.ekleToolStripMenuItem5.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem5.Text = "Ekle";
            this.ekleToolStripMenuItem5.Click += new System.EventHandler(this.ekleToolStripMenuItem5_Click);
            // 
            // düzenleSilToolStripMenuItem
            // 
            this.düzenleSilToolStripMenuItem.Name = "düzenleSilToolStripMenuItem";
            this.düzenleSilToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.düzenleSilToolStripMenuItem.Text = "Düzenle - Sil";
            this.düzenleSilToolStripMenuItem.Click += new System.EventHandler(this.düzenleSilToolStripMenuItem_Click);
            // 
            // dersİşlemleriToolStripMenuItem
            // 
            this.dersİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem6,
            this.düzenleSilToolStripMenuItem1});
            this.dersİşlemleriToolStripMenuItem.Name = "dersİşlemleriToolStripMenuItem";
            this.dersİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.dersİşlemleriToolStripMenuItem.Text = "Ders İşlemleri";
            // 
            // ekleToolStripMenuItem6
            // 
            this.ekleToolStripMenuItem6.Name = "ekleToolStripMenuItem6";
            this.ekleToolStripMenuItem6.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem6.Text = "Ekle";
            this.ekleToolStripMenuItem6.Click += new System.EventHandler(this.ekleToolStripMenuItem6_Click);
            // 
            // düzenleSilToolStripMenuItem1
            // 
            this.düzenleSilToolStripMenuItem1.Name = "düzenleSilToolStripMenuItem1";
            this.düzenleSilToolStripMenuItem1.Size = new System.Drawing.Size(139, 22);
            this.düzenleSilToolStripMenuItem1.Text = "Düzenle - Sil";
            this.düzenleSilToolStripMenuItem1.Click += new System.EventHandler(this.düzenleSilToolStripMenuItem1_Click);
            // 
            // harfliSistemAyarlarıToolStripMenuItem
            // 
            this.harfliSistemAyarlarıToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem4,
            this.düzenleToolStripMenuItem2});
            this.harfliSistemAyarlarıToolStripMenuItem.Name = "harfliSistemAyarlarıToolStripMenuItem";
            this.harfliSistemAyarlarıToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.harfliSistemAyarlarıToolStripMenuItem.Text = "Harfli Sistem Ayarları";
            // 
            // ekleToolStripMenuItem4
            // 
            this.ekleToolStripMenuItem4.Name = "ekleToolStripMenuItem4";
            this.ekleToolStripMenuItem4.Size = new System.Drawing.Size(139, 22);
            this.ekleToolStripMenuItem4.Text = "Ekle";
            this.ekleToolStripMenuItem4.Click += new System.EventHandler(this.ekleToolStripMenuItem4_Click);
            // 
            // düzenleToolStripMenuItem2
            // 
            this.düzenleToolStripMenuItem2.Name = "düzenleToolStripMenuItem2";
            this.düzenleToolStripMenuItem2.Size = new System.Drawing.Size(139, 22);
            this.düzenleToolStripMenuItem2.Text = "Düzenle - Sil";
            this.düzenleToolStripMenuItem2.Click += new System.EventHandler(this.düzenleToolStripMenuItem2_Click);
            // 
            // otomasyonAyarlarıToolStripMenuItem
            // 
            this.otomasyonAyarlarıToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ekleToolStripMenuItem3});
            this.otomasyonAyarlarıToolStripMenuItem.Name = "otomasyonAyarlarıToolStripMenuItem";
            this.otomasyonAyarlarıToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.otomasyonAyarlarıToolStripMenuItem.Text = "Otomasyon Ayarları";
            // 
            // ekleToolStripMenuItem3
            // 
            this.ekleToolStripMenuItem3.Name = "ekleToolStripMenuItem3";
            this.ekleToolStripMenuItem3.Size = new System.Drawing.Size(116, 22);
            this.ekleToolStripMenuItem3.Text = "Düzenle";
            this.ekleToolStripMenuItem3.Click += new System.EventHandler(this.ekleToolStripMenuItem3_Click);
            // 
            // gboxOgrenciler
            // 
            this.gboxOgrenciler.Controls.Add(this.btnRefOgr);
            this.gboxOgrenciler.Controls.Add(this.lblEnYukGNO);
            this.gboxOgrenciler.Controls.Add(this.lblToplamOgr);
            this.gboxOgrenciler.Controls.Add(this.label2);
            this.gboxOgrenciler.Controls.Add(this.label1);
            this.gboxOgrenciler.ForeColor = System.Drawing.Color.White;
            this.gboxOgrenciler.Location = new System.Drawing.Point(6, 6);
            this.gboxOgrenciler.Name = "gboxOgrenciler";
            this.gboxOgrenciler.Size = new System.Drawing.Size(382, 114);
            this.gboxOgrenciler.TabIndex = 3;
            this.gboxOgrenciler.TabStop = false;
            this.gboxOgrenciler.Text = "Öğrenciler";
            // 
            // btnRefOgr
            // 
            this.btnRefOgr.BackColor = System.Drawing.Color.Transparent;
            this.btnRefOgr.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.refresh2;
            this.btnRefOgr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefOgr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefOgr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefOgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRefOgr.ForeColor = System.Drawing.Color.Transparent;
            this.btnRefOgr.Location = new System.Drawing.Point(344, 80);
            this.btnRefOgr.Name = "btnRefOgr";
            this.btnRefOgr.Size = new System.Drawing.Size(32, 28);
            this.btnRefOgr.TabIndex = 2;
            this.btnRefOgr.UseVisualStyleBackColor = false;
            this.btnRefOgr.Click += new System.EventHandler(this.btnRefOgr_Click);
            // 
            // lblEnYukGNO
            // 
            this.lblEnYukGNO.AutoSize = true;
            this.lblEnYukGNO.Location = new System.Drawing.Point(139, 47);
            this.lblEnYukGNO.Name = "lblEnYukGNO";
            this.lblEnYukGNO.Size = new System.Drawing.Size(13, 13);
            this.lblEnYukGNO.TabIndex = 1;
            this.lblEnYukGNO.Text = "0";
            // 
            // lblToplamOgr
            // 
            this.lblToplamOgr.AutoSize = true;
            this.lblToplamOgr.Location = new System.Drawing.Point(139, 25);
            this.lblToplamOgr.Name = "lblToplamOgr";
            this.lblToplamOgr.Size = new System.Drawing.Size(13, 13);
            this.lblToplamOgr.TabIndex = 1;
            this.lblToplamOgr.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "En Yüksek GNO : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Toplam Öğrenci Sayısı : ";
            // 
            // gboxAka
            // 
            this.gboxAka.Controls.Add(this.btnRefAka);
            this.gboxAka.Controls.Add(this.lblToplamAka);
            this.gboxAka.Controls.Add(this.label6);
            this.gboxAka.ForeColor = System.Drawing.Color.White;
            this.gboxAka.Location = new System.Drawing.Point(8, 6);
            this.gboxAka.Name = "gboxAka";
            this.gboxAka.Size = new System.Drawing.Size(277, 114);
            this.gboxAka.TabIndex = 3;
            this.gboxAka.TabStop = false;
            this.gboxAka.Text = "Akademisyenler";
            // 
            // btnRefAka
            // 
            this.btnRefAka.BackColor = System.Drawing.Color.Transparent;
            this.btnRefAka.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.refresh2;
            this.btnRefAka.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefAka.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefAka.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefAka.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRefAka.ForeColor = System.Drawing.Color.Transparent;
            this.btnRefAka.Location = new System.Drawing.Point(239, 80);
            this.btnRefAka.Name = "btnRefAka";
            this.btnRefAka.Size = new System.Drawing.Size(32, 28);
            this.btnRefAka.TabIndex = 2;
            this.btnRefAka.UseVisualStyleBackColor = false;
            this.btnRefAka.Click += new System.EventHandler(this.btnRefAka_Click);
            // 
            // lblToplamAka
            // 
            this.lblToplamAka.AutoSize = true;
            this.lblToplamAka.Location = new System.Drawing.Point(159, 25);
            this.lblToplamAka.Name = "lblToplamAka";
            this.lblToplamAka.Size = new System.Drawing.Size(13, 13);
            this.lblToplamAka.TabIndex = 1;
            this.lblToplamAka.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Toplam Akademisyen Sayısı : ";
            // 
            // gboxBolumler
            // 
            this.gboxBolumler.Controls.Add(this.dataGridView1);
            this.gboxBolumler.Controls.Add(this.btnRefBol);
            this.gboxBolumler.Controls.Add(this.lblToplamBolum);
            this.gboxBolumler.Controls.Add(this.label9);
            this.gboxBolumler.Controls.Add(this.label5);
            this.gboxBolumler.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gboxBolumler.ForeColor = System.Drawing.Color.White;
            this.gboxBolumler.Location = new System.Drawing.Point(3, 3);
            this.gboxBolumler.Name = "gboxBolumler";
            this.gboxBolumler.Size = new System.Drawing.Size(910, 462);
            this.gboxBolumler.TabIndex = 3;
            this.gboxBolumler.TabStop = false;
            this.gboxBolumler.Text = "Bölümler";
            // 
            // btnRefBol
            // 
            this.btnRefBol.BackColor = System.Drawing.Color.Transparent;
            this.btnRefBol.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.refresh2;
            this.btnRefBol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefBol.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefBol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefBol.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRefBol.ForeColor = System.Drawing.Color.Transparent;
            this.btnRefBol.Location = new System.Drawing.Point(872, 12);
            this.btnRefBol.Name = "btnRefBol";
            this.btnRefBol.Size = new System.Drawing.Size(32, 28);
            this.btnRefBol.TabIndex = 2;
            this.btnRefBol.UseVisualStyleBackColor = false;
            this.btnRefBol.Click += new System.EventHandler(this.btnRefBol_Click);
            // 
            // lblToplamBolum
            // 
            this.lblToplamBolum.AutoSize = true;
            this.lblToplamBolum.Location = new System.Drawing.Point(120, 24);
            this.lblToplamBolum.Name = "lblToplamBolum";
            this.lblToplamBolum.Size = new System.Drawing.Size(13, 13);
            this.lblToplamBolum.TabIndex = 1;
            this.lblToplamBolum.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Bölümler :  ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Toplam Bölüm Sayısı : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Controls.Add(this.btnRefDers);
            this.groupBox1.Controls.Add(this.lblToplamDers);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(910, 462);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dersler";
            // 
            // btnRefDers
            // 
            this.btnRefDers.BackColor = System.Drawing.Color.Transparent;
            this.btnRefDers.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.refresh2;
            this.btnRefDers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefDers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefDers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefDers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRefDers.ForeColor = System.Drawing.Color.Transparent;
            this.btnRefDers.Location = new System.Drawing.Point(872, 11);
            this.btnRefDers.Name = "btnRefDers";
            this.btnRefDers.Size = new System.Drawing.Size(32, 28);
            this.btnRefDers.TabIndex = 2;
            this.btnRefDers.UseVisualStyleBackColor = false;
            this.btnRefDers.Click += new System.EventHandler(this.btnRefDers_Click);
            // 
            // lblToplamDers
            // 
            this.lblToplamDers.AutoSize = true;
            this.lblToplamDers.ForeColor = System.Drawing.Color.White;
            this.lblToplamDers.Location = new System.Drawing.Point(118, 24);
            this.lblToplamDers.Name = "lblToplamDers";
            this.lblToplamDers.Size = new System.Drawing.Size(13, 13);
            this.lblToplamDers.TabIndex = 1;
            this.lblToplamDers.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(6, 49);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Dersler :  ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(6, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Toplam Ders Sayısı : ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lboxHarfliNotlar);
            this.groupBox2.Controls.Add(this.btnRefNotlar);
            this.groupBox2.Controls.Add(this.lblToplamHarfliNotlar);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(942, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(210, 482);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Harfli Notlar ve Değerleri";
            // 
            // lboxHarfliNotlar
            // 
            this.lboxHarfliNotlar.FormattingEnabled = true;
            this.lboxHarfliNotlar.Location = new System.Drawing.Point(6, 65);
            this.lboxHarfliNotlar.Name = "lboxHarfliNotlar";
            this.lboxHarfliNotlar.Size = new System.Drawing.Size(199, 407);
            this.lboxHarfliNotlar.TabIndex = 3;
            // 
            // btnRefNotlar
            // 
            this.btnRefNotlar.BackColor = System.Drawing.Color.Transparent;
            this.btnRefNotlar.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.refresh2;
            this.btnRefNotlar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefNotlar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefNotlar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefNotlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRefNotlar.ForeColor = System.Drawing.Color.Transparent;
            this.btnRefNotlar.Location = new System.Drawing.Point(172, 13);
            this.btnRefNotlar.Name = "btnRefNotlar";
            this.btnRefNotlar.Size = new System.Drawing.Size(32, 28);
            this.btnRefNotlar.TabIndex = 2;
            this.btnRefNotlar.UseVisualStyleBackColor = false;
            this.btnRefNotlar.Click += new System.EventHandler(this.btnRefNotlar_Click);
            // 
            // lblToplamHarfliNotlar
            // 
            this.lblToplamHarfliNotlar.AutoSize = true;
            this.lblToplamHarfliNotlar.Location = new System.Drawing.Point(131, 25);
            this.lblToplamHarfliNotlar.Name = "lblToplamHarfliNotlar";
            this.lblToplamHarfliNotlar.Size = new System.Drawing.Size(13, 13);
            this.lblToplamHarfliNotlar.TabIndex = 1;
            this.lblToplamHarfliNotlar.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Notlar : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Toplam Harfli Not Sayısı : ";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabOgrenciler);
            this.tabControl1.Controls.Add(this.tabBolumler);
            this.tabControl1.Controls.Add(this.tabAkademisyenler);
            this.tabControl1.Controls.Add(this.tabDersler);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(924, 494);
            this.tabControl1.TabIndex = 4;
            // 
            // tabOgrenciler
            // 
            this.tabOgrenciler.BackColor = System.Drawing.Color.SteelBlue;
            this.tabOgrenciler.Controls.Add(this.gboxOgrenciler);
            this.tabOgrenciler.ForeColor = System.Drawing.Color.Black;
            this.tabOgrenciler.Location = new System.Drawing.Point(4, 22);
            this.tabOgrenciler.Name = "tabOgrenciler";
            this.tabOgrenciler.Padding = new System.Windows.Forms.Padding(3);
            this.tabOgrenciler.Size = new System.Drawing.Size(916, 468);
            this.tabOgrenciler.TabIndex = 0;
            this.tabOgrenciler.Text = "Öğrenciler";
            // 
            // tabBolumler
            // 
            this.tabBolumler.BackColor = System.Drawing.Color.SteelBlue;
            this.tabBolumler.Controls.Add(this.gboxBolumler);
            this.tabBolumler.Location = new System.Drawing.Point(4, 22);
            this.tabBolumler.Name = "tabBolumler";
            this.tabBolumler.Padding = new System.Windows.Forms.Padding(3);
            this.tabBolumler.Size = new System.Drawing.Size(916, 468);
            this.tabBolumler.TabIndex = 1;
            this.tabBolumler.Text = "Bölümler";
            // 
            // tabAkademisyenler
            // 
            this.tabAkademisyenler.BackColor = System.Drawing.Color.SteelBlue;
            this.tabAkademisyenler.Controls.Add(this.gboxAka);
            this.tabAkademisyenler.Location = new System.Drawing.Point(4, 22);
            this.tabAkademisyenler.Name = "tabAkademisyenler";
            this.tabAkademisyenler.Padding = new System.Windows.Forms.Padding(3);
            this.tabAkademisyenler.Size = new System.Drawing.Size(916, 468);
            this.tabAkademisyenler.TabIndex = 2;
            this.tabAkademisyenler.Text = "Akademisyenler";
            // 
            // tabDersler
            // 
            this.tabDersler.BackColor = System.Drawing.Color.SteelBlue;
            this.tabDersler.Controls.Add(this.groupBox1);
            this.tabDersler.Location = new System.Drawing.Point(4, 22);
            this.tabDersler.Name = "tabDersler";
            this.tabDersler.Padding = new System.Windows.Forms.Padding(3);
            this.tabDersler.Size = new System.Drawing.Size(916, 468);
            this.tabDersler.TabIndex = 3;
            this.tabDersler.Text = "Dersler";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.SteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colBolumKodu,
            this.colBolumAdi,
            this.colBolumBaskani});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(3, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(904, 394);
            this.dataGridView1.TabIndex = 3;
            // 
            // colBolumKodu
            // 
            this.colBolumKodu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBolumKodu.HeaderText = "Bolum Kodu";
            this.colBolumKodu.Name = "colBolumKodu";
            // 
            // colBolumAdi
            // 
            this.colBolumAdi.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBolumAdi.HeaderText = "Bolum Adi";
            this.colBolumAdi.Name = "colBolumAdi";
            // 
            // colBolumBaskani
            // 
            this.colBolumBaskani.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colBolumBaskani.HeaderText = "Bolum Baskani";
            this.colBolumBaskani.Name = "colBolumBaskani";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.SteelBlue;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDersKodu,
            this.colDersAdi,
            this.colDersKredi,
            this.colDersBolum,
            this.colDersSinif});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView2.Location = new System.Drawing.Point(3, 111);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(904, 348);
            this.dataGridView2.TabIndex = 3;
            // 
            // colDersKodu
            // 
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.colDersKodu.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDersKodu.HeaderText = "Ders Kodu";
            this.colDersKodu.Name = "colDersKodu";
            this.colDersKodu.ReadOnly = true;
            // 
            // colDersAdi
            // 
            this.colDersAdi.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.colDersAdi.DefaultCellStyle = dataGridViewCellStyle4;
            this.colDersAdi.FillWeight = 20.61856F;
            this.colDersAdi.HeaderText = "Ders Adi";
            this.colDersAdi.Name = "colDersAdi";
            this.colDersAdi.ReadOnly = true;
            // 
            // colDersKredi
            // 
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.colDersKredi.DefaultCellStyle = dataGridViewCellStyle5;
            this.colDersKredi.FillWeight = 338.1443F;
            this.colDersKredi.HeaderText = "Ders Kredi";
            this.colDersKredi.Name = "colDersKredi";
            this.colDersKredi.ReadOnly = true;
            // 
            // colDersBolum
            // 
            this.colDersBolum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.colDersBolum.DefaultCellStyle = dataGridViewCellStyle6;
            this.colDersBolum.FillWeight = 20.61856F;
            this.colDersBolum.HeaderText = "Ders Bolum";
            this.colDersBolum.Name = "colDersBolum";
            this.colDersBolum.ReadOnly = true;
            // 
            // colDersSinif
            // 
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.colDersSinif.DefaultCellStyle = dataGridViewCellStyle7;
            this.colDersSinif.FillWeight = 20.61856F;
            this.colDersSinif.HeaderText = "Ders Sinif";
            this.colDersSinif.Name = "colDersSinif";
            this.colDersSinif.ReadOnly = true;
            // 
            // frmBilgiIslem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(924, 540);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmBilgiIslem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bilgi İşlem Sistemi";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmBilgiIslem_FormClosed);
            this.Load += new System.EventHandler(this.frmBilgiIslem_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gboxOgrenciler.ResumeLayout(false);
            this.gboxOgrenciler.PerformLayout();
            this.gboxAka.ResumeLayout(false);
            this.gboxAka.PerformLayout();
            this.gboxBolumler.ResumeLayout(false);
            this.gboxBolumler.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabOgrenciler.ResumeLayout(false);
            this.tabBolumler.ResumeLayout(false);
            this.tabAkademisyenler.ResumeLayout(false);
            this.tabDersler.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslblBilgiNoAdi;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dosyaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işlemlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem akademisyenEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bilgiİşlemPersoneliEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem düzenlemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem düzenlemeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem düzenleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otomasyonAyarlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem harfliSistemAyarlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem düzenleToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem3;
        private System.Windows.Forms.GroupBox gboxOgrenciler;
        private System.Windows.Forms.Label lblEnYukGNO;
        private System.Windows.Forms.Label lblToplamOgr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gboxAka;
        private System.Windows.Forms.Label lblToplamAka;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gboxBolumler;
        private System.Windows.Forms.Label lblToplamBolum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblToplamDers;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnRefOgr;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnRefAka;
        private System.Windows.Forms.Button btnRefBol;
        private System.Windows.Forms.Button btnRefDers;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lboxHarfliNotlar;
        private System.Windows.Forms.Button btnRefNotlar;
        private System.Windows.Forms.Label lblToplamHarfliNotlar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStripMenuItem bölümİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem düzenleSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dersİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ekleToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem düzenleSilToolStripMenuItem1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabOgrenciler;
        private System.Windows.Forms.TabPage tabBolumler;
        private System.Windows.Forms.TabPage tabAkademisyenler;
        private System.Windows.Forms.TabPage tabDersler;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBolumKodu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBolumAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBolumBaskani;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDersKodu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDersAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDersKredi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDersBolum;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDersSinif;
    }
}