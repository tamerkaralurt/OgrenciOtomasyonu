﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiPersonelDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiPersonelDuzenle));
            this.rbPerTC = new System.Windows.Forms.RadioButton();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.btnPerAra = new System.Windows.Forms.Button();
            this.rbPerNo = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAraPerSoyadi = new System.Windows.Forms.TextBox();
            this.rbPerSoyadi = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAraPerTC = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rbPerAdi = new System.Windows.Forms.RadioButton();
            this.txtAraPerNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAraPerAdi = new System.Windows.Forms.TextBox();
            this.cbDuzenlePerDuzenle = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDuzenlePerSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenlePerTC = new System.Windows.Forms.TextBox();
            this.cboxDuzenlePerBolum = new System.Windows.Forms.ComboBox();
            this.btnPerDuzenle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDuzenlePerAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDuzenlePerAdres = new System.Windows.Forms.TextBox();
            this.txtDuzenlePerTel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.btnPerSil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.lblPerNo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDuzenlePerSoyadi = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.gboxOgrAra.SuspendLayout();
            this.panelOgrAra.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbPerTC
            // 
            this.rbPerTC.AutoSize = true;
            this.rbPerTC.Location = new System.Drawing.Point(134, 24);
            this.rbPerTC.Name = "rbPerTC";
            this.rbPerTC.Size = new System.Drawing.Size(116, 17);
            this.rbPerTC.TabIndex = 2;
            this.rbPerTC.TabStop = true;
            this.rbPerTC.Text = "Bil. Is. Personeli TC";
            this.rbPerTC.UseVisualStyleBackColor = true;
            this.rbPerTC.CheckedChanged += new System.EventHandler(this.rbPerTC_CheckedChanged);
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.btnPerAra);
            this.gboxOgrAra.Controls.Add(this.rbPerNo);
            this.gboxOgrAra.Controls.Add(this.label9);
            this.gboxOgrAra.Controls.Add(this.txtAraPerSoyadi);
            this.gboxOgrAra.Controls.Add(this.rbPerSoyadi);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraPerTC);
            this.gboxOgrAra.Controls.Add(this.label11);
            this.gboxOgrAra.Controls.Add(this.rbPerAdi);
            this.gboxOgrAra.Controls.Add(this.txtAraPerNo);
            this.gboxOgrAra.Controls.Add(this.label10);
            this.gboxOgrAra.Controls.Add(this.txtAraPerAdi);
            this.gboxOgrAra.Controls.Add(this.rbPerTC);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(513, 396);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Bilgi İşlem Personeli Arama";
            // 
            // btnPerAra
            // 
            this.btnPerAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btnPerAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPerAra.ForeColor = System.Drawing.Color.White;
            this.btnPerAra.Location = new System.Drawing.Point(189, 172);
            this.btnPerAra.Name = "btnPerAra";
            this.btnPerAra.Size = new System.Drawing.Size(242, 50);
            this.btnPerAra.TabIndex = 6;
            this.btnPerAra.Text = "ARA";
            this.btnPerAra.UseVisualStyleBackColor = false;
            this.btnPerAra.Click += new System.EventHandler(this.btnPerAra_Click);
            // 
            // rbPerNo
            // 
            this.rbPerNo.AutoSize = true;
            this.rbPerNo.Location = new System.Drawing.Point(18, 24);
            this.rbPerNo.Name = "rbPerNo";
            this.rbPerNo.Size = new System.Drawing.Size(116, 17);
            this.rbPerNo.TabIndex = 1;
            this.rbPerNo.TabStop = true;
            this.rbPerNo.Text = "Bil. Is. Personeli No";
            this.rbPerNo.UseVisualStyleBackColor = true;
            this.rbPerNo.CheckedChanged += new System.EventHandler(this.rbPerNo_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(76, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Bil. Is. Personeli TC : ";
            // 
            // txtAraPerSoyadi
            // 
            this.txtAraPerSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraPerSoyadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraPerSoyadi.Location = new System.Drawing.Point(189, 145);
            this.txtAraPerSoyadi.Name = "txtAraPerSoyadi";
            this.txtAraPerSoyadi.Size = new System.Drawing.Size(242, 20);
            this.txtAraPerSoyadi.TabIndex = 5;
            // 
            // rbPerSoyadi
            // 
            this.rbPerSoyadi.AutoSize = true;
            this.rbPerSoyadi.Location = new System.Drawing.Point(367, 24);
            this.rbPerSoyadi.Name = "rbPerSoyadi";
            this.rbPerSoyadi.Size = new System.Drawing.Size(134, 17);
            this.rbPerSoyadi.TabIndex = 4;
            this.rbPerSoyadi.TabStop = true;
            this.rbPerSoyadi.Text = "Bil. Is. Personeli Soyadi";
            this.rbPerSoyadi.UseVisualStyleBackColor = true;
            this.rbPerSoyadi.CheckedChanged += new System.EventHandler(this.rbPerSoyadi_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bil. Is. Personeli No : ";
            // 
            // txtAraPerTC
            // 
            this.txtAraPerTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraPerTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraPerTC.Location = new System.Drawing.Point(189, 93);
            this.txtAraPerTC.Name = "txtAraPerTC";
            this.txtAraPerTC.Size = new System.Drawing.Size(242, 20);
            this.txtAraPerTC.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(58, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Bil. Is. Personeli Soyadi : ";
            // 
            // rbPerAdi
            // 
            this.rbPerAdi.AutoSize = true;
            this.rbPerAdi.Location = new System.Drawing.Point(250, 24);
            this.rbPerAdi.Name = "rbPerAdi";
            this.rbPerAdi.Size = new System.Drawing.Size(117, 17);
            this.rbPerAdi.TabIndex = 3;
            this.rbPerAdi.TabStop = true;
            this.rbPerAdi.Text = "Bil. Is. Personeli Adi";
            this.rbPerAdi.UseVisualStyleBackColor = true;
            this.rbPerAdi.CheckedChanged += new System.EventHandler(this.rbPerAdi_CheckedChanged);
            // 
            // txtAraPerNo
            // 
            this.txtAraPerNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraPerNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraPerNo.Location = new System.Drawing.Point(189, 67);
            this.txtAraPerNo.Name = "txtAraPerNo";
            this.txtAraPerNo.Size = new System.Drawing.Size(242, 20);
            this.txtAraPerNo.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(75, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Bil. Is. Personeli Adi : ";
            // 
            // txtAraPerAdi
            // 
            this.txtAraPerAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraPerAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraPerAdi.Location = new System.Drawing.Point(189, 119);
            this.txtAraPerAdi.Name = "txtAraPerAdi";
            this.txtAraPerAdi.Size = new System.Drawing.Size(242, 20);
            this.txtAraPerAdi.TabIndex = 5;
            // 
            // cbDuzenlePerDuzenle
            // 
            this.cbDuzenlePerDuzenle.AutoSize = true;
            this.cbDuzenlePerDuzenle.Location = new System.Drawing.Point(232, 271);
            this.cbDuzenlePerDuzenle.Name = "cbDuzenlePerDuzenle";
            this.cbDuzenlePerDuzenle.Size = new System.Drawing.Size(142, 17);
            this.cbDuzenlePerDuzenle.TabIndex = 8;
            this.cbDuzenlePerDuzenle.Text = "Bil. Is. Personeli Düzenle";
            this.cbDuzenlePerDuzenle.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bil. Is. Personeli TC : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Bil. Is. Personeli Soyadi : ";
            // 
            // cbDuzenlePerSil
            // 
            this.cbDuzenlePerSil.AutoSize = true;
            this.cbDuzenlePerSil.Location = new System.Drawing.Point(118, 271);
            this.cbDuzenlePerSil.Name = "cbDuzenlePerSil";
            this.cbDuzenlePerSil.Size = new System.Drawing.Size(114, 17);
            this.cbDuzenlePerSil.TabIndex = 7;
            this.cbDuzenlePerSil.Text = "Bil. Is. Personeli Sil";
            this.cbDuzenlePerSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenlePerTC
            // 
            this.txtDuzenlePerTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenlePerTC.Location = new System.Drawing.Point(152, 50);
            this.txtDuzenlePerTC.Name = "txtDuzenlePerTC";
            this.txtDuzenlePerTC.Size = new System.Drawing.Size(292, 20);
            this.txtDuzenlePerTC.TabIndex = 1;
            // 
            // cboxDuzenlePerBolum
            // 
            this.cboxDuzenlePerBolum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDuzenlePerBolum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDuzenlePerBolum.FormattingEnabled = true;
            this.cboxDuzenlePerBolum.Location = new System.Drawing.Point(154, 233);
            this.cboxDuzenlePerBolum.Name = "cboxDuzenlePerBolum";
            this.cboxDuzenlePerBolum.Size = new System.Drawing.Size(291, 21);
            this.cboxDuzenlePerBolum.TabIndex = 6;
            // 
            // btnPerDuzenle
            // 
            this.btnPerDuzenle.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnPerDuzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPerDuzenle.ForeColor = System.Drawing.Color.White;
            this.btnPerDuzenle.Location = new System.Drawing.Point(226, 319);
            this.btnPerDuzenle.Name = "btnPerDuzenle";
            this.btnPerDuzenle.Size = new System.Drawing.Size(166, 50);
            this.btnPerDuzenle.TabIndex = 9;
            this.btnPerDuzenle.Text = "DÜZENLE";
            this.btnPerDuzenle.UseVisualStyleBackColor = false;
            this.btnPerDuzenle.Click += new System.EventHandler(this.btnPerDuzenle_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Bil. Is. Personeli Telefon : ";
            // 
            // txtDuzenlePerAdi
            // 
            this.txtDuzenlePerAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenlePerAdi.Location = new System.Drawing.Point(153, 76);
            this.txtDuzenlePerAdi.Name = "txtDuzenlePerAdi";
            this.txtDuzenlePerAdi.Size = new System.Drawing.Size(292, 20);
            this.txtDuzenlePerAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Bil. Is. Personeli Adi : ";
            // 
            // txtDuzenlePerAdres
            // 
            this.txtDuzenlePerAdres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenlePerAdres.Location = new System.Drawing.Point(153, 154);
            this.txtDuzenlePerAdres.Multiline = true;
            this.txtDuzenlePerAdres.Name = "txtDuzenlePerAdres";
            this.txtDuzenlePerAdres.Size = new System.Drawing.Size(292, 73);
            this.txtDuzenlePerAdres.TabIndex = 5;
            // 
            // txtDuzenlePerTel
            // 
            this.txtDuzenlePerTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenlePerTel.Location = new System.Drawing.Point(153, 128);
            this.txtDuzenlePerTel.Name = "txtDuzenlePerTel";
            this.txtDuzenlePerTel.Size = new System.Drawing.Size(292, 20);
            this.txtDuzenlePerTel.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Bil. Is. Personeli Adres: ";
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(486, 57);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(521, 401);
            this.panelOgrAra.TabIndex = 18;
            // 
            // btnPerSil
            // 
            this.btnPerSil.BackColor = System.Drawing.Color.Maroon;
            this.btnPerSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPerSil.ForeColor = System.Drawing.Color.White;
            this.btnPerSil.Location = new System.Drawing.Point(54, 319);
            this.btnPerSil.Name = "btnPerSil";
            this.btnPerSil.Size = new System.Drawing.Size(166, 50);
            this.btnPerSil.TabIndex = 10;
            this.btnPerSil.Text = "SİL";
            this.btnPerSil.UseVisualStyleBackColor = false;
            this.btnPerSil.Click += new System.EventHandler(this.btnPerSil_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Bil. Is. Personeli Bölümü : ";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(468, 38);
            this.panel1.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(86, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(306, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Bilgi İşlem Personeli Düzenle Bölümü";
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(468, 402);
            this.panelOgrDuzenle.TabIndex = 16;
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.lblPerNo);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenlePerDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label7);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.label4);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenlePerSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenlePerTC);
            this.gboxOgrDuzenle.Controls.Add(this.cboxDuzenlePerBolum);
            this.gboxOgrDuzenle.Controls.Add(this.btnPerDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label5);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenlePerAdi);
            this.gboxOgrDuzenle.Controls.Add(this.label3);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenlePerAdres);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenlePerTel);
            this.gboxOgrDuzenle.Controls.Add(this.btnPerSil);
            this.gboxOgrDuzenle.Controls.Add(this.label8);
            this.gboxOgrDuzenle.Controls.Add(this.label6);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenlePerSoyadi);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(460, 396);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Bilgi İşlem Personeli Düzenle";
            // 
            // lblPerNo
            // 
            this.lblPerNo.AutoSize = true;
            this.lblPerNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPerNo.Location = new System.Drawing.Point(152, 28);
            this.lblPerNo.Name = "lblPerNo";
            this.lblPerNo.Size = new System.Drawing.Size(0, 15);
            this.lblPerNo.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Bil. Is. Personeli No : ";
            // 
            // txtDuzenlePerSoyadi
            // 
            this.txtDuzenlePerSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenlePerSoyadi.Location = new System.Drawing.Point(153, 102);
            this.txtDuzenlePerSoyadi.Name = "txtDuzenlePerSoyadi";
            this.txtDuzenlePerSoyadi.Size = new System.Drawing.Size(292, 20);
            this.txtDuzenlePerSoyadi.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(486, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(521, 38);
            this.panel2.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(121, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(292, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Bilgi İşlem Personeli Arama Bölümü";
            // 
            // frmBilgiPersonelDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1021, 470);
            this.Controls.Add(this.panelOgrAra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrDuzenle);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiPersonelDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bilgi İşlem Personeli Duzenle";
            this.Load += new System.EventHandler(this.frmBilgiPersonelDuzenle_Load);
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.panelOgrAra.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbPerTC;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.Button btnPerAra;
        private System.Windows.Forms.RadioButton rbPerNo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAraPerSoyadi;
        private System.Windows.Forms.RadioButton rbPerSoyadi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAraPerTC;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rbPerAdi;
        private System.Windows.Forms.TextBox txtAraPerNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAraPerAdi;
        private System.Windows.Forms.CheckBox cbDuzenlePerDuzenle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbDuzenlePerSil;
        private System.Windows.Forms.TextBox txtDuzenlePerTC;
        private System.Windows.Forms.ComboBox cboxDuzenlePerBolum;
        private System.Windows.Forms.Button btnPerDuzenle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDuzenlePerAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDuzenlePerAdres;
        private System.Windows.Forms.TextBox txtDuzenlePerTel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.Button btnPerSil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.TextBox txtDuzenlePerSoyadi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblPerNo;
        private System.Windows.Forms.Label label7;
    }
}