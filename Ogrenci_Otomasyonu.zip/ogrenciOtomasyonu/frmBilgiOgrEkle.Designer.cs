﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiOgrEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiOgrEkle));
            this.panel1 = new System.Windows.Forms.Panel();
            this.gboxOgrEkle = new System.Windows.Forms.GroupBox();
            this.btnOgrenciKaydet = new System.Windows.Forms.Button();
            this.txtogrAdres = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboxBolum = new System.Windows.Forms.ComboBox();
            this.txtogrTelefon = new System.Windows.Forms.TextBox();
            this.txtogrTC = new System.Windows.Forms.TextBox();
            this.txtogrSoyadi = new System.Windows.Forms.TextBox();
            this.txtogrAdi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gboxOgrEkle.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.gboxOgrEkle);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(351, 283);
            this.panel1.TabIndex = 0;
            // 
            // gboxOgrEkle
            // 
            this.gboxOgrEkle.Controls.Add(this.btnOgrenciKaydet);
            this.gboxOgrEkle.Controls.Add(this.txtogrAdres);
            this.gboxOgrEkle.Controls.Add(this.label5);
            this.gboxOgrEkle.Controls.Add(this.cboxBolum);
            this.gboxOgrEkle.Controls.Add(this.txtogrTelefon);
            this.gboxOgrEkle.Controls.Add(this.txtogrTC);
            this.gboxOgrEkle.Controls.Add(this.txtogrSoyadi);
            this.gboxOgrEkle.Controls.Add(this.txtogrAdi);
            this.gboxOgrEkle.Controls.Add(this.label6);
            this.gboxOgrEkle.Controls.Add(this.label4);
            this.gboxOgrEkle.Controls.Add(this.label3);
            this.gboxOgrEkle.Controls.Add(this.label2);
            this.gboxOgrEkle.Controls.Add(this.label1);
            this.gboxOgrEkle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrEkle.Location = new System.Drawing.Point(3, 3);
            this.gboxOgrEkle.Name = "gboxOgrEkle";
            this.gboxOgrEkle.Size = new System.Drawing.Size(343, 277);
            this.gboxOgrEkle.TabIndex = 0;
            this.gboxOgrEkle.TabStop = false;
            this.gboxOgrEkle.Text = "Öğrenci Ekle";
            // 
            // btnOgrenciKaydet
            // 
            this.btnOgrenciKaydet.BackColor = System.Drawing.Color.SeaGreen;
            this.btnOgrenciKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciKaydet.Location = new System.Drawing.Point(119, 225);
            this.btnOgrenciKaydet.Name = "btnOgrenciKaydet";
            this.btnOgrenciKaydet.Size = new System.Drawing.Size(211, 41);
            this.btnOgrenciKaydet.TabIndex = 20;
            this.btnOgrenciKaydet.Text = "KAYDET";
            this.btnOgrenciKaydet.UseVisualStyleBackColor = false;
            this.btnOgrenciKaydet.Click += new System.EventHandler(this.btnOgrenciKaydet_Click_1);
            // 
            // txtogrAdres
            // 
            this.txtogrAdres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtogrAdres.Location = new System.Drawing.Point(119, 137);
            this.txtogrAdres.Multiline = true;
            this.txtogrAdres.Name = "txtogrAdres";
            this.txtogrAdres.Size = new System.Drawing.Size(211, 82);
            this.txtogrAdres.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Öğrencinin Adres : ";
            // 
            // cboxBolum
            // 
            this.cboxBolum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxBolum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxBolum.FormattingEnabled = true;
            this.cboxBolum.Location = new System.Drawing.Point(119, 110);
            this.cboxBolum.Name = "cboxBolum";
            this.cboxBolum.Size = new System.Drawing.Size(211, 21);
            this.cboxBolum.TabIndex = 18;
            // 
            // txtogrTelefon
            // 
            this.txtogrTelefon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtogrTelefon.Location = new System.Drawing.Point(119, 84);
            this.txtogrTelefon.Name = "txtogrTelefon";
            this.txtogrTelefon.Size = new System.Drawing.Size(211, 20);
            this.txtogrTelefon.TabIndex = 17;
            // 
            // txtogrTC
            // 
            this.txtogrTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtogrTC.Location = new System.Drawing.Point(119, 60);
            this.txtogrTC.Name = "txtogrTC";
            this.txtogrTC.Size = new System.Drawing.Size(211, 20);
            this.txtogrTC.TabIndex = 16;
            // 
            // txtogrSoyadi
            // 
            this.txtogrSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtogrSoyadi.Location = new System.Drawing.Point(119, 37);
            this.txtogrSoyadi.Name = "txtogrSoyadi";
            this.txtogrSoyadi.Size = new System.Drawing.Size(211, 20);
            this.txtogrSoyadi.TabIndex = 14;
            // 
            // txtogrAdi
            // 
            this.txtogrAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtogrAdi.Location = new System.Drawing.Point(119, 13);
            this.txtogrAdi.Name = "txtogrAdi";
            this.txtogrAdi.Size = new System.Drawing.Size(211, 20);
            this.txtogrAdi.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Öğrencinin Bölüm : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Öğrencinin Telefon : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Öğrencinin TC : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Öğrencinin Soyadı : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Öğrencinin Adı : ";
            // 
            // frmBilgiOgrEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(376, 308);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiOgrEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Öğrenci Ekleme";
            this.Load += new System.EventHandler(this.frmOgrEkle_Load);
            this.panel1.ResumeLayout(false);
            this.gboxOgrEkle.ResumeLayout(false);
            this.gboxOgrEkle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gboxOgrEkle;
        private System.Windows.Forms.Button btnOgrenciKaydet;
        private System.Windows.Forms.TextBox txtogrAdres;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboxBolum;
        private System.Windows.Forms.TextBox txtogrTelefon;
        private System.Windows.Forms.TextBox txtogrTC;
        private System.Windows.Forms.TextBox txtogrSoyadi;
        private System.Windows.Forms.TextBox txtogrAdi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;

    }
}