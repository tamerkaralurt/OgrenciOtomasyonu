﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiAkaDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiAkaDuzenle));
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.lblAkaNo = new System.Windows.Forms.Label();
            this.cbDuzenleAkaDuzenle = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDuzenleAkaSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenleAkaTC = new System.Windows.Forms.TextBox();
            this.cboxDuzenleAkaBolum = new System.Windows.Forms.ComboBox();
            this.btnAkaDuzenle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDuzenleAkaAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDuzenleAkaAdres = new System.Windows.Forms.TextBox();
            this.txtDuzenleAkaTel = new System.Windows.Forms.TextBox();
            this.btnAkaSil = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDuzenleAkaSoyadi = new System.Windows.Forms.TextBox();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAraAkaNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAraAkaAdi = new System.Windows.Forms.TextBox();
            this.rbAkaTC = new System.Windows.Forms.RadioButton();
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.btnAkaAra = new System.Windows.Forms.Button();
            this.rbAkaNo = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAraAkaSoyadi = new System.Windows.Forms.TextBox();
            this.rbAkaSoyadi = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAraAkaTC = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rbAkaAdi = new System.Windows.Forms.RadioButton();
            this.panel2.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrAra.SuspendLayout();
            this.gboxOgrAra.SuspendLayout();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(122, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(251, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Akademisyen Düzenle Bölümü";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(399, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(475, 38);
            this.panel2.TabIndex = 15;
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.lblAkaNo);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleAkaDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label7);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.label4);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleAkaSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleAkaTC);
            this.gboxOgrDuzenle.Controls.Add(this.cboxDuzenleAkaBolum);
            this.gboxOgrDuzenle.Controls.Add(this.btnAkaDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label5);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleAkaAdi);
            this.gboxOgrDuzenle.Controls.Add(this.label3);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleAkaAdres);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleAkaTel);
            this.gboxOgrDuzenle.Controls.Add(this.btnAkaSil);
            this.gboxOgrDuzenle.Controls.Add(this.label8);
            this.gboxOgrDuzenle.Controls.Add(this.label6);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleAkaSoyadi);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(373, 374);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Akademisyen Düzenle";
            // 
            // lblAkaNo
            // 
            this.lblAkaNo.AutoSize = true;
            this.lblAkaNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAkaNo.Location = new System.Drawing.Point(135, 26);
            this.lblAkaNo.Name = "lblAkaNo";
            this.lblAkaNo.Size = new System.Drawing.Size(0, 15);
            this.lblAkaNo.TabIndex = 11;
            // 
            // cbDuzenleAkaDuzenle
            // 
            this.cbDuzenleAkaDuzenle.AutoSize = true;
            this.cbDuzenleAkaDuzenle.Location = new System.Drawing.Point(192, 276);
            this.cbDuzenleAkaDuzenle.Name = "cbDuzenleAkaDuzenle";
            this.cbDuzenleAkaDuzenle.Size = new System.Drawing.Size(133, 17);
            this.cbDuzenleAkaDuzenle.TabIndex = 8;
            this.cbDuzenleAkaDuzenle.Text = "Akademisyeni Düzenle";
            this.cbDuzenleAkaDuzenle.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Akademisyen No : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Akademisyen TC : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Akademisyen Soyadi : ";
            // 
            // cbDuzenleAkaSil
            // 
            this.cbDuzenleAkaSil.AutoSize = true;
            this.cbDuzenleAkaSil.Location = new System.Drawing.Point(81, 276);
            this.cbDuzenleAkaSil.Name = "cbDuzenleAkaSil";
            this.cbDuzenleAkaSil.Size = new System.Drawing.Size(105, 17);
            this.cbDuzenleAkaSil.TabIndex = 7;
            this.cbDuzenleAkaSil.Text = "Akademisyeni Sil";
            this.cbDuzenleAkaSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenleAkaTC
            // 
            this.txtDuzenleAkaTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleAkaTC.Location = new System.Drawing.Point(138, 51);
            this.txtDuzenleAkaTC.Name = "txtDuzenleAkaTC";
            this.txtDuzenleAkaTC.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleAkaTC.TabIndex = 1;
            // 
            // cboxDuzenleAkaBolum
            // 
            this.cboxDuzenleAkaBolum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDuzenleAkaBolum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDuzenleAkaBolum.FormattingEnabled = true;
            this.cboxDuzenleAkaBolum.Location = new System.Drawing.Point(139, 234);
            this.cboxDuzenleAkaBolum.Name = "cboxDuzenleAkaBolum";
            this.cboxDuzenleAkaBolum.Size = new System.Drawing.Size(219, 21);
            this.cboxDuzenleAkaBolum.TabIndex = 6;
            // 
            // btnAkaDuzenle
            // 
            this.btnAkaDuzenle.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnAkaDuzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAkaDuzenle.ForeColor = System.Drawing.Color.White;
            this.btnAkaDuzenle.Location = new System.Drawing.Point(192, 309);
            this.btnAkaDuzenle.Name = "btnAkaDuzenle";
            this.btnAkaDuzenle.Size = new System.Drawing.Size(166, 50);
            this.btnAkaDuzenle.TabIndex = 9;
            this.btnAkaDuzenle.Text = "DÜZENLE";
            this.btnAkaDuzenle.UseVisualStyleBackColor = false;
            this.btnAkaDuzenle.Click += new System.EventHandler(this.btnAkaDuzenle_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Akademisyen Telefon : ";
            // 
            // txtDuzenleAkaAdi
            // 
            this.txtDuzenleAkaAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleAkaAdi.Location = new System.Drawing.Point(138, 77);
            this.txtDuzenleAkaAdi.Name = "txtDuzenleAkaAdi";
            this.txtDuzenleAkaAdi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleAkaAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Akademisyen Adi : ";
            // 
            // txtDuzenleAkaAdres
            // 
            this.txtDuzenleAkaAdres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleAkaAdres.Location = new System.Drawing.Point(138, 155);
            this.txtDuzenleAkaAdres.Multiline = true;
            this.txtDuzenleAkaAdres.Name = "txtDuzenleAkaAdres";
            this.txtDuzenleAkaAdres.Size = new System.Drawing.Size(220, 73);
            this.txtDuzenleAkaAdres.TabIndex = 5;
            // 
            // txtDuzenleAkaTel
            // 
            this.txtDuzenleAkaTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleAkaTel.Location = new System.Drawing.Point(138, 129);
            this.txtDuzenleAkaTel.Name = "txtDuzenleAkaTel";
            this.txtDuzenleAkaTel.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleAkaTel.TabIndex = 4;
            // 
            // btnAkaSil
            // 
            this.btnAkaSil.BackColor = System.Drawing.Color.Maroon;
            this.btnAkaSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAkaSil.ForeColor = System.Drawing.Color.White;
            this.btnAkaSil.Location = new System.Drawing.Point(20, 309);
            this.btnAkaSil.Name = "btnAkaSil";
            this.btnAkaSil.Size = new System.Drawing.Size(166, 50);
            this.btnAkaSil.TabIndex = 10;
            this.btnAkaSil.Text = "SİL";
            this.btnAkaSil.UseVisualStyleBackColor = false;
            this.btnAkaSil.Click += new System.EventHandler(this.btnAkaSil_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Akademisyen Adres: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Akademisyen Bölümü : ";
            // 
            // txtDuzenleAkaSoyadi
            // 
            this.txtDuzenleAkaSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleAkaSoyadi.Location = new System.Drawing.Point(138, 103);
            this.txtDuzenleAkaSoyadi.Name = "txtDuzenleAkaSoyadi";
            this.txtDuzenleAkaSoyadi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleAkaSoyadi.TabIndex = 3;
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(381, 380);
            this.panelOgrDuzenle.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(73, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(251, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Akademisyen Düzenle Bölümü";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(381, 38);
            this.panel1.TabIndex = 13;
            // 
            // txtAraAkaNo
            // 
            this.txtAraAkaNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraAkaNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraAkaNo.Location = new System.Drawing.Point(147, 68);
            this.txtAraAkaNo.Name = "txtAraAkaNo";
            this.txtAraAkaNo.Size = new System.Drawing.Size(242, 20);
            this.txtAraAkaNo.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 122);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Akademisyen Adi : ";
            // 
            // txtAraAkaAdi
            // 
            this.txtAraAkaAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraAkaAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraAkaAdi.Location = new System.Drawing.Point(147, 120);
            this.txtAraAkaAdi.Name = "txtAraAkaAdi";
            this.txtAraAkaAdi.Size = new System.Drawing.Size(242, 20);
            this.txtAraAkaAdi.TabIndex = 5;
            // 
            // rbAkaTC
            // 
            this.rbAkaTC.AutoSize = true;
            this.rbAkaTC.Location = new System.Drawing.Point(123, 24);
            this.rbAkaTC.Name = "rbAkaTC";
            this.rbAkaTC.Size = new System.Drawing.Size(105, 17);
            this.rbAkaTC.TabIndex = 2;
            this.rbAkaTC.TabStop = true;
            this.rbAkaTC.Text = "Akademisyen TC";
            this.rbAkaTC.UseVisualStyleBackColor = true;
            this.rbAkaTC.CheckedChanged += new System.EventHandler(this.rbAkaTC_CheckedChanged);
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(399, 57);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(475, 379);
            this.panelOgrAra.TabIndex = 14;
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.btnAkaAra);
            this.gboxOgrAra.Controls.Add(this.rbAkaNo);
            this.gboxOgrAra.Controls.Add(this.label9);
            this.gboxOgrAra.Controls.Add(this.txtAraAkaSoyadi);
            this.gboxOgrAra.Controls.Add(this.rbAkaSoyadi);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraAkaTC);
            this.gboxOgrAra.Controls.Add(this.label11);
            this.gboxOgrAra.Controls.Add(this.rbAkaAdi);
            this.gboxOgrAra.Controls.Add(this.txtAraAkaNo);
            this.gboxOgrAra.Controls.Add(this.label10);
            this.gboxOgrAra.Controls.Add(this.txtAraAkaAdi);
            this.gboxOgrAra.Controls.Add(this.rbAkaTC);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(467, 373);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Akademisyen Arama";
            // 
            // btnAkaAra
            // 
            this.btnAkaAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAkaAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAkaAra.ForeColor = System.Drawing.Color.White;
            this.btnAkaAra.Location = new System.Drawing.Point(147, 173);
            this.btnAkaAra.Name = "btnAkaAra";
            this.btnAkaAra.Size = new System.Drawing.Size(242, 50);
            this.btnAkaAra.TabIndex = 6;
            this.btnAkaAra.Text = "ARA";
            this.btnAkaAra.UseVisualStyleBackColor = false;
            this.btnAkaAra.Click += new System.EventHandler(this.btnAkaAra_Click);
            // 
            // rbAkaNo
            // 
            this.rbAkaNo.AutoSize = true;
            this.rbAkaNo.Location = new System.Drawing.Point(18, 24);
            this.rbAkaNo.Name = "rbAkaNo";
            this.rbAkaNo.Size = new System.Drawing.Size(105, 17);
            this.rbAkaNo.TabIndex = 1;
            this.rbAkaNo.TabStop = true;
            this.rbAkaNo.Text = "Akademisyen No";
            this.rbAkaNo.UseVisualStyleBackColor = true;
            this.rbAkaNo.CheckedChanged += new System.EventHandler(this.rbAkaNo_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Akademisyen TC : ";
            // 
            // txtAraAkaSoyadi
            // 
            this.txtAraAkaSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraAkaSoyadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraAkaSoyadi.Location = new System.Drawing.Point(147, 146);
            this.txtAraAkaSoyadi.Name = "txtAraAkaSoyadi";
            this.txtAraAkaSoyadi.Size = new System.Drawing.Size(242, 20);
            this.txtAraAkaSoyadi.TabIndex = 5;
            // 
            // rbAkaSoyadi
            // 
            this.rbAkaSoyadi.AutoSize = true;
            this.rbAkaSoyadi.Location = new System.Drawing.Point(334, 24);
            this.rbAkaSoyadi.Name = "rbAkaSoyadi";
            this.rbAkaSoyadi.Size = new System.Drawing.Size(123, 17);
            this.rbAkaSoyadi.TabIndex = 4;
            this.rbAkaSoyadi.TabStop = true;
            this.rbAkaSoyadi.Text = "Akademisyen Soyadi";
            this.rbAkaSoyadi.UseVisualStyleBackColor = true;
            this.rbAkaSoyadi.CheckedChanged += new System.EventHandler(this.rbAkaSoyadi_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Akademisyen No : ";
            // 
            // txtAraAkaTC
            // 
            this.txtAraAkaTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraAkaTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraAkaTC.Location = new System.Drawing.Point(147, 94);
            this.txtAraAkaTC.Name = "txtAraAkaTC";
            this.txtAraAkaTC.Size = new System.Drawing.Size(242, 20);
            this.txtAraAkaTC.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 148);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Akademisyen Soyadi : ";
            // 
            // rbAkaAdi
            // 
            this.rbAkaAdi.AutoSize = true;
            this.rbAkaAdi.Location = new System.Drawing.Point(228, 24);
            this.rbAkaAdi.Name = "rbAkaAdi";
            this.rbAkaAdi.Size = new System.Drawing.Size(106, 17);
            this.rbAkaAdi.TabIndex = 3;
            this.rbAkaAdi.TabStop = true;
            this.rbAkaAdi.Text = "Akademisyen Adi";
            this.rbAkaAdi.UseVisualStyleBackColor = true;
            this.rbAkaAdi.CheckedChanged += new System.EventHandler(this.rbAkaAdi_CheckedChanged);
            // 
            // frmBilgiAkaDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(885, 447);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelOgrDuzenle);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrAra);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiAkaDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Akademisyen Düzenleme Silme";
            this.Load += new System.EventHandler(this.frmBilgiAkaDuzenle_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrAra.ResumeLayout(false);
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.CheckBox cbDuzenleAkaDuzenle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbDuzenleAkaSil;
        private System.Windows.Forms.TextBox txtDuzenleAkaTC;
        private System.Windows.Forms.ComboBox cboxDuzenleAkaBolum;
        private System.Windows.Forms.Button btnAkaDuzenle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDuzenleAkaAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDuzenleAkaAdres;
        private System.Windows.Forms.TextBox txtDuzenleAkaTel;
        private System.Windows.Forms.Button btnAkaSil;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDuzenleAkaSoyadi;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAraAkaNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAraAkaAdi;
        private System.Windows.Forms.RadioButton rbAkaTC;
        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.Button btnAkaAra;
        private System.Windows.Forms.RadioButton rbAkaNo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAraAkaSoyadi;
        private System.Windows.Forms.RadioButton rbAkaSoyadi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAraAkaTC;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rbAkaAdi;
        private System.Windows.Forms.Label lblAkaNo;
        private System.Windows.Forms.Label label7;
    }
}