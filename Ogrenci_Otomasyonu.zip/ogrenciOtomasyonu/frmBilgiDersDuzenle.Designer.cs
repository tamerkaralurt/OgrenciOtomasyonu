﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiDersDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiDersDuzenle));
            this.rbdersKodu = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.cbDuzenleDersDuzenle = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDuzenleDersSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenleDersKodu = new System.Windows.Forms.TextBox();
            this.cboxDuzenleDersBolum = new System.Windows.Forms.ComboBox();
            this.btndersDuzenle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btndersAra = new System.Windows.Forms.Button();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAraDersAdi = new System.Windows.Forms.TextBox();
            this.txtAraDersKodu = new System.Windows.Forms.TextBox();
            this.rbdersAdi = new System.Windows.Forms.RadioButton();
            this.txtDuzenleDersAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDuzenleDersSinif = new System.Windows.Forms.TextBox();
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.btndersSil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.txtDuzenleDersKredi = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.cboxDersHocasi = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gboxOgrAra.SuspendLayout();
            this.panelOgrAra.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbdersKodu
            // 
            this.rbdersKodu.AutoSize = true;
            this.rbdersKodu.Location = new System.Drawing.Point(78, 26);
            this.rbdersKodu.Name = "rbdersKodu";
            this.rbdersKodu.Size = new System.Drawing.Size(75, 17);
            this.rbdersKodu.TabIndex = 1;
            this.rbdersKodu.TabStop = true;
            this.rbdersKodu.Text = "Ders Kodu";
            this.rbdersKodu.UseVisualStyleBackColor = true;
            this.rbdersKodu.CheckedChanged += new System.EventHandler(this.rbdersKodu_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Ders Adi : ";
            // 
            // cbDuzenleDersDuzenle
            // 
            this.cbDuzenleDersDuzenle.AutoSize = true;
            this.cbDuzenleDersDuzenle.Location = new System.Drawing.Point(187, 271);
            this.cbDuzenleDersDuzenle.Name = "cbDuzenleDersDuzenle";
            this.cbDuzenleDersDuzenle.Size = new System.Drawing.Size(90, 17);
            this.cbDuzenleDersDuzenle.TabIndex = 8;
            this.cbDuzenleDersDuzenle.Text = "Ders Düzenle";
            this.cbDuzenleDersDuzenle.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ders Kodu :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Ders Kredi :";
            // 
            // cbDuzenleDersSil
            // 
            this.cbDuzenleDersSil.AutoSize = true;
            this.cbDuzenleDersSil.Location = new System.Drawing.Point(76, 271);
            this.cbDuzenleDersSil.Name = "cbDuzenleDersSil";
            this.cbDuzenleDersSil.Size = new System.Drawing.Size(64, 17);
            this.cbDuzenleDersSil.TabIndex = 7;
            this.cbDuzenleDersSil.Text = "Dersi Sil";
            this.cbDuzenleDersSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenleDersKodu
            // 
            this.txtDuzenleDersKodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleDersKodu.Location = new System.Drawing.Point(119, 51);
            this.txtDuzenleDersKodu.Name = "txtDuzenleDersKodu";
            this.txtDuzenleDersKodu.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleDersKodu.TabIndex = 1;
            // 
            // cboxDuzenleDersBolum
            // 
            this.cboxDuzenleDersBolum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDuzenleDersBolum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDuzenleDersBolum.FormattingEnabled = true;
            this.cboxDuzenleDersBolum.Location = new System.Drawing.Point(119, 155);
            this.cboxDuzenleDersBolum.Name = "cboxDuzenleDersBolum";
            this.cboxDuzenleDersBolum.Size = new System.Drawing.Size(219, 21);
            this.cboxDuzenleDersBolum.TabIndex = 6;
            // 
            // btndersDuzenle
            // 
            this.btndersDuzenle.BackColor = System.Drawing.SystemColors.Highlight;
            this.btndersDuzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btndersDuzenle.ForeColor = System.Drawing.Color.White;
            this.btndersDuzenle.Location = new System.Drawing.Point(187, 294);
            this.btndersDuzenle.Name = "btndersDuzenle";
            this.btndersDuzenle.Size = new System.Drawing.Size(166, 50);
            this.btndersDuzenle.TabIndex = 9;
            this.btndersDuzenle.Text = "DÜZENLE";
            this.btndersDuzenle.UseVisualStyleBackColor = false;
            this.btndersDuzenle.Click += new System.EventHandler(this.btndersDuzenle_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ders Sınıf :";
            // 
            // btndersAra
            // 
            this.btndersAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btndersAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btndersAra.ForeColor = System.Drawing.Color.White;
            this.btndersAra.Location = new System.Drawing.Point(78, 102);
            this.btndersAra.Name = "btndersAra";
            this.btndersAra.Size = new System.Drawing.Size(242, 50);
            this.btndersAra.TabIndex = 6;
            this.btndersAra.Text = "ARA";
            this.btndersAra.UseVisualStyleBackColor = false;
            this.btndersAra.Click += new System.EventHandler(this.btndersAra_Click);
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.btndersAra);
            this.gboxOgrAra.Controls.Add(this.rbdersKodu);
            this.gboxOgrAra.Controls.Add(this.label9);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraDersAdi);
            this.gboxOgrAra.Controls.Add(this.txtAraDersKodu);
            this.gboxOgrAra.Controls.Add(this.rbdersAdi);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(330, 356);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Ders Arama";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ders Kodu : ";
            // 
            // txtAraDersAdi
            // 
            this.txtAraDersAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraDersAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraDersAdi.Location = new System.Drawing.Point(78, 76);
            this.txtAraDersAdi.Name = "txtAraDersAdi";
            this.txtAraDersAdi.Size = new System.Drawing.Size(242, 20);
            this.txtAraDersAdi.TabIndex = 5;
            // 
            // txtAraDersKodu
            // 
            this.txtAraDersKodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraDersKodu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraDersKodu.Location = new System.Drawing.Point(78, 50);
            this.txtAraDersKodu.Name = "txtAraDersKodu";
            this.txtAraDersKodu.Size = new System.Drawing.Size(242, 20);
            this.txtAraDersKodu.TabIndex = 5;
            // 
            // rbdersAdi
            // 
            this.rbdersAdi.AutoSize = true;
            this.rbdersAdi.Location = new System.Drawing.Point(159, 26);
            this.rbdersAdi.Name = "rbdersAdi";
            this.rbdersAdi.Size = new System.Drawing.Size(65, 17);
            this.rbdersAdi.TabIndex = 2;
            this.rbdersAdi.TabStop = true;
            this.rbdersAdi.Text = "Ders Adi";
            this.rbdersAdi.UseVisualStyleBackColor = true;
            this.rbdersAdi.CheckedChanged += new System.EventHandler(this.rbdersAdi_CheckedChanged);
            // 
            // txtDuzenleDersAdi
            // 
            this.txtDuzenleDersAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleDersAdi.Location = new System.Drawing.Point(119, 77);
            this.txtDuzenleDersAdi.Name = "txtDuzenleDersAdi";
            this.txtDuzenleDersAdi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleDersAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Des Adi :";
            // 
            // txtDuzenleDersSinif
            // 
            this.txtDuzenleDersSinif.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleDersSinif.Location = new System.Drawing.Point(119, 129);
            this.txtDuzenleDersSinif.Name = "txtDuzenleDersSinif";
            this.txtDuzenleDersSinif.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleDersSinif.TabIndex = 4;
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(399, 57);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(338, 361);
            this.panelOgrAra.TabIndex = 18;
            // 
            // btndersSil
            // 
            this.btndersSil.BackColor = System.Drawing.Color.Maroon;
            this.btndersSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btndersSil.ForeColor = System.Drawing.Color.White;
            this.btndersSil.Location = new System.Drawing.Point(15, 294);
            this.btndersSil.Name = "btndersSil";
            this.btndersSil.Size = new System.Drawing.Size(166, 50);
            this.btndersSil.TabIndex = 10;
            this.btndersSil.Text = "SİL";
            this.btndersSil.UseVisualStyleBackColor = false;
            this.btndersSil.Click += new System.EventHandler(this.btndersSil_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Ders Bölümü :";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(381, 38);
            this.panel1.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(73, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(183, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Ders Düzenle Bölümü";
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(381, 362);
            this.panelOgrDuzenle.TabIndex = 16;
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.cboxDersHocasi);
            this.gboxOgrDuzenle.Controls.Add(this.label7);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleDersDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.label4);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleDersSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleDersKodu);
            this.gboxOgrDuzenle.Controls.Add(this.cboxDuzenleDersBolum);
            this.gboxOgrDuzenle.Controls.Add(this.btndersDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label5);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleDersAdi);
            this.gboxOgrDuzenle.Controls.Add(this.label3);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleDersSinif);
            this.gboxOgrDuzenle.Controls.Add(this.btndersSil);
            this.gboxOgrDuzenle.Controls.Add(this.label6);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleDersKredi);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(373, 356);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Ders Düzenle";
            // 
            // txtDuzenleDersKredi
            // 
            this.txtDuzenleDersKredi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleDersKredi.Location = new System.Drawing.Point(119, 103);
            this.txtDuzenleDersKredi.Name = "txtDuzenleDersKredi";
            this.txtDuzenleDersKredi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleDersKredi.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(399, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(338, 38);
            this.panel2.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(94, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(183, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Ders Düzenle Bölümü";
            // 
            // cboxDersHocasi
            // 
            this.cboxDersHocasi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDersHocasi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDersHocasi.FormattingEnabled = true;
            this.cboxDersHocasi.Location = new System.Drawing.Point(119, 182);
            this.cboxDersHocasi.Name = "cboxDersHocasi";
            this.cboxDersHocasi.Size = new System.Drawing.Size(219, 21);
            this.cboxDersHocasi.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Ders Hocası :";
            // 
            // frmBilgiDersDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(750, 433);
            this.Controls.Add(this.panelOgrAra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrDuzenle);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiDersDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ders Düzenle";
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.panelOgrAra.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbdersKodu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox cbDuzenleDersDuzenle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbDuzenleDersSil;
        private System.Windows.Forms.TextBox txtDuzenleDersKodu;
        private System.Windows.Forms.ComboBox cboxDuzenleDersBolum;
        private System.Windows.Forms.Button btndersDuzenle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btndersAra;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAraDersAdi;
        private System.Windows.Forms.TextBox txtAraDersKodu;
        private System.Windows.Forms.RadioButton rbdersAdi;
        private System.Windows.Forms.TextBox txtDuzenleDersAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDuzenleDersSinif;
        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.Button btndersSil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.TextBox txtDuzenleDersKredi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboxDersHocasi;
        private System.Windows.Forms.Label label7;
    }
}