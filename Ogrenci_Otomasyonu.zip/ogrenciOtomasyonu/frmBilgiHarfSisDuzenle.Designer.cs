﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiHarfSisDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiHarfSisDuzenle));
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblHarfAdi = new System.Windows.Forms.Label();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.cbDuzenleOgrDuzenle = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbDuzenleOgrSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenleHarfDeger = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAraHarfAdi = new System.Windows.Forms.TextBox();
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.btnAra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrAra.SuspendLayout();
            this.gboxOgrAra.SuspendLayout();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(3, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(207, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Harfli Not Arama Bölümü";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(273, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(223, 38);
            this.panel2.TabIndex = 15;
            // 
            // lblHarfAdi
            // 
            this.lblHarfAdi.AutoSize = true;
            this.lblHarfAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHarfAdi.Location = new System.Drawing.Point(106, 22);
            this.lblHarfAdi.Name = "lblHarfAdi";
            this.lblHarfAdi.Size = new System.Drawing.Size(15, 15);
            this.lblHarfAdi.TabIndex = 11;
            this.lblHarfAdi.Text = "0";
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.lblHarfAdi);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleOgrDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label14);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleOgrSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleHarfDeger);
            this.gboxOgrDuzenle.Controls.Add(this.button1);
            this.gboxOgrDuzenle.Controls.Add(this.btnSil);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(246, 155);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Harfli Not Düzenle";
            // 
            // cbDuzenleOgrDuzenle
            // 
            this.cbDuzenleOgrDuzenle.AutoSize = true;
            this.cbDuzenleOgrDuzenle.Location = new System.Drawing.Point(109, 81);
            this.cbDuzenleOgrDuzenle.Name = "cbDuzenleOgrDuzenle";
            this.cbDuzenleOgrDuzenle.Size = new System.Drawing.Size(112, 17);
            this.cbDuzenleOgrDuzenle.TabIndex = 8;
            this.cbDuzenleOgrDuzenle.Text = "Harfli Not Düzenle";
            this.cbDuzenleOgrDuzenle.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(33, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Harfli Not Adı : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Harfli Not Değeri : ";
            // 
            // cbDuzenleOgrSil
            // 
            this.cbDuzenleOgrSil.AutoSize = true;
            this.cbDuzenleOgrSil.Location = new System.Drawing.Point(19, 81);
            this.cbDuzenleOgrSil.Name = "cbDuzenleOgrSil";
            this.cbDuzenleOgrSil.Size = new System.Drawing.Size(84, 17);
            this.cbDuzenleOgrSil.TabIndex = 7;
            this.cbDuzenleOgrSil.Text = "Harfli Not Sil";
            this.cbDuzenleOgrSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenleHarfDeger
            // 
            this.txtDuzenleHarfDeger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleHarfDeger.Location = new System.Drawing.Point(109, 41);
            this.txtDuzenleHarfDeger.Name = "txtDuzenleHarfDeger";
            this.txtDuzenleHarfDeger.Size = new System.Drawing.Size(108, 20);
            this.txtDuzenleHarfDeger.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(117, 104);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 37);
            this.button1.TabIndex = 9;
            this.button1.Text = "DÜZENLE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.Maroon;
            this.btnSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSil.ForeColor = System.Drawing.Color.White;
            this.btnSil.Location = new System.Drawing.Point(7, 104);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(104, 37);
            this.btnSil.TabIndex = 10;
            this.btnSil.Text = "SİL";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(255, 164);
            this.panelOgrDuzenle.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(18, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(221, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Harfli Not Düzenle Bölümü";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(255, 38);
            this.panel1.TabIndex = 13;
            // 
            // txtAraHarfAdi
            // 
            this.txtAraHarfAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraHarfAdi.Location = new System.Drawing.Point(94, 20);
            this.txtAraHarfAdi.Name = "txtAraHarfAdi";
            this.txtAraHarfAdi.Size = new System.Drawing.Size(104, 20);
            this.txtAraHarfAdi.TabIndex = 5;
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(273, 56);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(223, 164);
            this.panelOgrAra.TabIndex = 14;
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.btnAra);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraHarfAdi);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(215, 156);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Harfli Not Arama";
            // 
            // btnAra
            // 
            this.btnAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAra.ForeColor = System.Drawing.Color.White;
            this.btnAra.Location = new System.Drawing.Point(94, 46);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(104, 37);
            this.btnAra.TabIndex = 6;
            this.btnAra.Text = "ARA";
            this.btnAra.UseVisualStyleBackColor = false;
            this.btnAra.Click += new System.EventHandler(this.btnAra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Harfli Not Adı : ";
            // 
            // frmBilgiHarfSisDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(510, 233);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelOgrDuzenle);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrAra);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiHarfSisDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Not - Harf Sistemi Düzenleme";
            this.Load += new System.EventHandler(this.frmBilgiHarfSisDuzenle_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrAra.ResumeLayout(false);
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblHarfAdi;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.CheckBox cbDuzenleOgrDuzenle;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbDuzenleOgrSil;
        private System.Windows.Forms.TextBox txtDuzenleHarfDeger;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAraHarfAdi;
        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.Button btnAra;
        private System.Windows.Forms.Label label1;
    }
}