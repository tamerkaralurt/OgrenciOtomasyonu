﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogrenciOtomasyonu
{
    public partial class frmAkaNotFinalGir : Form
    {
        public frmAkaNotFinalGir()
        {
            InitializeComponent();
        }

        SqlBaglantisi sqlBaglan = new SqlBaglantisi();
        string dersSinifAl, dersBolumAl, dersKoduAl,harfnotu;
        double vize=0, final=0, ortalama=0;

        private void frmAkaNotFinalGir_Load(object sender, EventArgs e)
        {
            try
            {
                frmAkaNotGirme frmAkaNotGirme = new frmAkaNotGirme();
                dersSinifAl = frmAkaNotGirme.dersSinifGonder;
                dersBolumAl = frmAkaNotGirme.dersBolumGonder;
                dersKoduAl = frmAkaNotGirme.dersKoduGonder;
                OgrenciCeK();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        private void OgrenciCeK()
        {
            try
            {
                sqlBaglan.BaglantiAc();
                sqlBaglan.sorgu.Parameters.Clear();
                sqlBaglan.sorgu.Connection = sqlBaglan.baglan;
                sqlBaglan.sorgu.CommandText = "SELECT ogr.ogrNo,ogr.ogrAdi + ' ' + ogr.ogrSoyadi AS adiSoyadi,ogr.ogrSinif,ders.dersKodu,ders.dersAdi,nott.dersVize,nott.dersFinal FROM tbl_notlar nott INNER JOIN tbl_ogrenciler ogr ON ogr.ogrNo = nott.ogrNo INNER JOIN tbl_dersler ders ON ders.dersKodu = nott.dersKodu WHERE ogr.ogrBolum = @ogrBolum AND ogr.ogrSinif = @ogrSinif AND ders.dersKodu = @dersKodu";
                sqlBaglan.sorgu.Parameters.AddWithValue("@ogrBolum", dersBolumAl);
                sqlBaglan.sorgu.Parameters.AddWithValue("@ogrSinif", int.Parse(dersSinifAl));
                sqlBaglan.sorgu.Parameters.AddWithValue("@dersKodu", dersKoduAl);
                sqlBaglan.da.SelectCommand = sqlBaglan.sorgu;
                DataTable dt = new DataTable();
                sqlBaglan.sorgu.ExecuteNonQuery();
                sqlBaglan.da.Fill(dt);
                foreach (DataRow item in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells[0].Value = item["ogrNo"].ToString();
                    dataGridView1.Rows[n].Cells[1].Value = item["adiSoyadi"].ToString();
                    dataGridView1.Rows[n].Cells[2].Value = item["ogrSinif"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["dersKodu"].ToString();
                    dataGridView1.Rows[n].Cells[4].Value = item["dersAdi"].ToString();
                    dataGridView1.Rows[n].Cells[5].Value = item["dersFinal"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlBaglan.BaglantiKapat();
                sqlBaglan.sorgu.Parameters.Clear();
            }
        }

        private void btnFinalGir_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboxVizeOnay.Checked)
                {
                    sqlBaglan.BaglantiAc();
                    sqlBaglan.sorgu.Parameters.Clear();
                    sqlBaglan.sorgu.Connection = sqlBaglan.baglan;

                    foreach (DataGridViewRow item in dataGridView1.Rows)
                    {
                        sqlBaglan.sorgu.CommandText = "SELECT * FROM tbl_notlar WHERE ogrNo=@ogrNo AND dersKodu=@dersKodu";
                        sqlBaglan.sorgu.Parameters.AddWithValue("@ogrNo", item.Cells[0].Value);
                        sqlBaglan.sorgu.Parameters.AddWithValue("@dersKodu", item.Cells[3].Value);
                        sqlBaglan.dataReader = sqlBaglan.sorgu.ExecuteReader();
                        if (!sqlBaglan.dataReader.Read()) //Eğer Değer Dönüyorsa Öğrencinin Daha Önce Notu Vardır. Update Komutuna Yönlendir.
                        {
                            vize = Convert.ToDouble(sqlBaglan.dataReader["dersVize"].ToString()); //Vizeyi Aldık.
                            sqlBaglan.sorgu.Parameters.Clear();
                            sqlBaglan.dataReader.Close();
                            if (Convert.ToDouble(item.Cells[5].Value.ToString()) >= 0 && Convert.ToDouble(item.Cells[5].Value.ToString()) <= 100)
                            {
                                final = Convert.ToDouble(item.Cells[5].Value.ToString());
                                ortalama = (vize * 0.4) + (final * 0.6);
                                OrtalamaHesapla ortalamaHesapla = new OrtalamaHesapla();
                                harfnotu = ortalamaHesapla.harfID(ortalamaHesapla.HarfliNotu(ortalama));
                                sqlBaglan.sorgu.CommandText = "INSERT INTO tbl_notlar (ogrNo,dersKodu,dersFinal,dersOrt,dersHarfID) VALUES (@ogrNo,@dersKodu,@dersFinal,@dersOrt,@dersHarfID)";
                                sqlBaglan.sorgu.Parameters.AddWithValue("@ogrNo", item.Cells[0].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersKodu", item.Cells[3].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersFinal", item.Cells[5].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersOrt", ortalama);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersHarfID",harfnotu);
                                sqlBaglan.sorgu.ExecuteNonQuery();
                            }
                            else
                            {
                                MessageBox.Show("LÜTFEN 0 ile 100 Arasında Bir Değer Giriniz!");
                            }
                        }
                        else
                        {
                            vize = Convert.ToDouble(sqlBaglan.dataReader["dersVize"].ToString()); //Vizeyi Aldık.
                            sqlBaglan.sorgu.Parameters.Clear();
                            sqlBaglan.dataReader.Close();
                            if (Convert.ToDouble(item.Cells[5].Value.ToString()) >= 0 && Convert.ToDouble(item.Cells[5].Value.ToString()) <= 100)
                            {
                                final = Convert.ToDouble(item.Cells[5].Value.ToString());
                                ortalama = (vize * 0.4)+(final * 0.6);
                                OrtalamaHesapla ortalamaHesapla = new OrtalamaHesapla();
                                harfnotu = ortalamaHesapla.harfID(ortalamaHesapla.HarfliNotu(ortalama)); //OrtalamaHesapla Classındaki Önce HarfliNotu Metodu Cagırldı Gelen Sonuc HarfID metoduna Gonderildi.
                                sqlBaglan.sorgu.CommandText = "UPDATE tbl_notlar SET dersFinal=@dersFinal,dersOrt=@dersOrt,dersHarfID=@dersHarfID WHERE ogrNo=@ogrNo AND dersKodu=@dersKodu";
                                sqlBaglan.sorgu.Parameters.AddWithValue("@ogrNo", item.Cells[0].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersKodu", item.Cells[3].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersFinal", item.Cells[5].Value);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersOrt", ortalama);
                                sqlBaglan.sorgu.Parameters.AddWithValue("@dersHarfID", harfnotu);
                                sqlBaglan.sorgu.ExecuteNonQuery();
                            }
                            else
                            {
                                MessageBox.Show("LÜTFEN 0 ile 100 Arasında Bir Değer Giriniz!");
                            }
                        }
                    }
                    MessageBox.Show("Final Notları Eklendi!");
                    dataGridView1.Rows.Clear();
                    dataGridView1.Refresh();
                }
                else
                {
                    MessageBox.Show("Lütfen İşlemi Onaylayınız..");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlBaglan.BaglantiKapat();
                sqlBaglan.sorgu.Parameters.Clear();
            }
        }
    }
}
