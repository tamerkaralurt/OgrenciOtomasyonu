﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiBolumDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiBolumDuzenle));
            this.rbBolKodu = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.cbDuzenleBolDuzenle = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbDuzenleBolSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenleBolKodu = new System.Windows.Forms.TextBox();
            this.cboxDuzenleBolBaskani = new System.Windows.Forms.ComboBox();
            this.btnABolDuzenle = new System.Windows.Forms.Button();
            this.btnBolAra = new System.Windows.Forms.Button();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.cboxBolumBaskani = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAraBolAdi = new System.Windows.Forms.TextBox();
            this.rbAkaAdi = new System.Windows.Forms.RadioButton();
            this.txtAraBolKodu = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rbBolAdi = new System.Windows.Forms.RadioButton();
            this.txtDuzenleBolAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.btnBolSil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.gboxOgrAra.SuspendLayout();
            this.panelOgrAra.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbBolKodu
            // 
            this.rbBolKodu.AutoSize = true;
            this.rbBolKodu.Location = new System.Drawing.Point(64, 24);
            this.rbBolKodu.Name = "rbBolKodu";
            this.rbBolKodu.Size = new System.Drawing.Size(82, 17);
            this.rbBolKodu.TabIndex = 1;
            this.rbBolKodu.TabStop = true;
            this.rbBolKodu.Text = "Bölüm Kodu";
            this.rbBolKodu.UseVisualStyleBackColor = true;
            this.rbBolKodu.CheckedChanged += new System.EventHandler(this.rbBolKodu_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Bölüm Adı : ";
            // 
            // cbDuzenleBolDuzenle
            // 
            this.cbDuzenleBolDuzenle.AutoSize = true;
            this.cbDuzenleBolDuzenle.Location = new System.Drawing.Point(188, 123);
            this.cbDuzenleBolDuzenle.Name = "cbDuzenleBolDuzenle";
            this.cbDuzenleBolDuzenle.Size = new System.Drawing.Size(103, 17);
            this.cbDuzenleBolDuzenle.TabIndex = 8;
            this.cbDuzenleBolDuzenle.Text = "Bölümü Düzenle";
            this.cbDuzenleBolDuzenle.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bölüm Kodu : ";
            // 
            // cbDuzenleBolSil
            // 
            this.cbDuzenleBolSil.AutoSize = true;
            this.cbDuzenleBolSil.Location = new System.Drawing.Point(77, 123);
            this.cbDuzenleBolSil.Name = "cbDuzenleBolSil";
            this.cbDuzenleBolSil.Size = new System.Drawing.Size(75, 17);
            this.cbDuzenleBolSil.TabIndex = 7;
            this.cbDuzenleBolSil.Text = "Bölümü Sil";
            this.cbDuzenleBolSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenleBolKodu
            // 
            this.txtDuzenleBolKodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleBolKodu.Location = new System.Drawing.Point(116, 24);
            this.txtDuzenleBolKodu.Name = "txtDuzenleBolKodu";
            this.txtDuzenleBolKodu.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleBolKodu.TabIndex = 1;
            // 
            // cboxDuzenleBolBaskani
            // 
            this.cboxDuzenleBolBaskani.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDuzenleBolBaskani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDuzenleBolBaskani.FormattingEnabled = true;
            this.cboxDuzenleBolBaskani.Location = new System.Drawing.Point(117, 76);
            this.cboxDuzenleBolBaskani.Name = "cboxDuzenleBolBaskani";
            this.cboxDuzenleBolBaskani.Size = new System.Drawing.Size(219, 21);
            this.cboxDuzenleBolBaskani.TabIndex = 6;
            // 
            // btnABolDuzenle
            // 
            this.btnABolDuzenle.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnABolDuzenle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnABolDuzenle.ForeColor = System.Drawing.Color.White;
            this.btnABolDuzenle.Location = new System.Drawing.Point(188, 156);
            this.btnABolDuzenle.Name = "btnABolDuzenle";
            this.btnABolDuzenle.Size = new System.Drawing.Size(166, 50);
            this.btnABolDuzenle.TabIndex = 9;
            this.btnABolDuzenle.Text = "DÜZENLE";
            this.btnABolDuzenle.UseVisualStyleBackColor = false;
            this.btnABolDuzenle.Click += new System.EventHandler(this.btnABolDuzenle_Click);
            // 
            // btnBolAra
            // 
            this.btnBolAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btnBolAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBolAra.ForeColor = System.Drawing.Color.White;
            this.btnBolAra.Location = new System.Drawing.Point(98, 133);
            this.btnBolAra.Name = "btnBolAra";
            this.btnBolAra.Size = new System.Drawing.Size(244, 50);
            this.btnBolAra.TabIndex = 6;
            this.btnBolAra.Text = "ARA";
            this.btnBolAra.UseVisualStyleBackColor = false;
            this.btnBolAra.Click += new System.EventHandler(this.btnBolAra_Click);
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.cboxBolumBaskani);
            this.gboxOgrAra.Controls.Add(this.btnBolAra);
            this.gboxOgrAra.Controls.Add(this.rbBolKodu);
            this.gboxOgrAra.Controls.Add(this.label9);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraBolAdi);
            this.gboxOgrAra.Controls.Add(this.rbAkaAdi);
            this.gboxOgrAra.Controls.Add(this.txtAraBolKodu);
            this.gboxOgrAra.Controls.Add(this.label10);
            this.gboxOgrAra.Controls.Add(this.rbBolAdi);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(363, 220);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Bölüm Arama";
            // 
            // cboxBolumBaskani
            // 
            this.cboxBolumBaskani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxBolumBaskani.FormattingEnabled = true;
            this.cboxBolumBaskani.Location = new System.Drawing.Point(101, 106);
            this.cboxBolumBaskani.Name = "cboxBolumBaskani";
            this.cboxBolumBaskani.Size = new System.Drawing.Size(241, 21);
            this.cboxBolumBaskani.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bölüm Kodu : ";
            // 
            // txtAraBolAdi
            // 
            this.txtAraBolAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraBolAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraBolAdi.Location = new System.Drawing.Point(100, 81);
            this.txtAraBolAdi.Name = "txtAraBolAdi";
            this.txtAraBolAdi.Size = new System.Drawing.Size(242, 20);
            this.txtAraBolAdi.TabIndex = 5;
            // 
            // rbAkaAdi
            // 
            this.rbAkaAdi.AutoSize = true;
            this.rbAkaAdi.Location = new System.Drawing.Point(230, 24);
            this.rbAkaAdi.Name = "rbAkaAdi";
            this.rbAkaAdi.Size = new System.Drawing.Size(106, 17);
            this.rbAkaAdi.TabIndex = 3;
            this.rbAkaAdi.TabStop = true;
            this.rbAkaAdi.Text = "Akademisyen Adi";
            this.rbAkaAdi.UseVisualStyleBackColor = true;
            this.rbAkaAdi.CheckedChanged += new System.EventHandler(this.rbAkaAdi_CheckedChanged);
            // 
            // txtAraBolKodu
            // 
            this.txtAraBolKodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraBolKodu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)), true);
            this.txtAraBolKodu.Location = new System.Drawing.Point(100, 55);
            this.txtAraBolKodu.Name = "txtAraBolKodu";
            this.txtAraBolKodu.Size = new System.Drawing.Size(242, 20);
            this.txtAraBolKodu.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Bölüm Başkanı : ";
            // 
            // rbBolAdi
            // 
            this.rbBolAdi.AutoSize = true;
            this.rbBolAdi.Location = new System.Drawing.Point(152, 25);
            this.rbBolAdi.Name = "rbBolAdi";
            this.rbBolAdi.Size = new System.Drawing.Size(72, 17);
            this.rbBolAdi.TabIndex = 2;
            this.rbBolAdi.TabStop = true;
            this.rbBolAdi.Text = "Bölüm Adı";
            this.rbBolAdi.UseVisualStyleBackColor = true;
            this.rbBolAdi.CheckedChanged += new System.EventHandler(this.rbBolAdi_CheckedChanged);
            // 
            // txtDuzenleBolAdi
            // 
            this.txtDuzenleBolAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleBolAdi.Location = new System.Drawing.Point(116, 50);
            this.txtDuzenleBolAdi.Name = "txtDuzenleBolAdi";
            this.txtDuzenleBolAdi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleBolAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Bölüm Adı : ";
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(399, 57);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(371, 225);
            this.panelOgrAra.TabIndex = 18;
            // 
            // btnBolSil
            // 
            this.btnBolSil.BackColor = System.Drawing.Color.Maroon;
            this.btnBolSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBolSil.ForeColor = System.Drawing.Color.White;
            this.btnBolSil.Location = new System.Drawing.Point(16, 156);
            this.btnBolSil.Name = "btnBolSil";
            this.btnBolSil.Size = new System.Drawing.Size(166, 50);
            this.btnBolSil.TabIndex = 10;
            this.btnBolSil.Text = "SİL";
            this.btnBolSil.UseVisualStyleBackColor = false;
            this.btnBolSil.Click += new System.EventHandler(this.btnBolSil_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Bölüm Başkanı : ";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(381, 38);
            this.panel1.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(99, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(195, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Bölüm Düzenle Bölümü";
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(381, 226);
            this.panelOgrDuzenle.TabIndex = 16;
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleBolDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleBolSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleBolKodu);
            this.gboxOgrDuzenle.Controls.Add(this.cboxDuzenleBolBaskani);
            this.gboxOgrDuzenle.Controls.Add(this.btnABolDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleBolAdi);
            this.gboxOgrDuzenle.Controls.Add(this.label3);
            this.gboxOgrDuzenle.Controls.Add(this.btnBolSil);
            this.gboxOgrDuzenle.Controls.Add(this.label6);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(373, 220);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Bölüm  Düzenle";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(399, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(371, 38);
            this.panel2.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(97, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(195, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Bölüm Düzenle Bölümü";
            // 
            // frmBilgiBolumDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(786, 295);
            this.Controls.Add(this.panelOgrAra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrDuzenle);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiBolumDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bölüm Düzenle";
            this.Load += new System.EventHandler(this.frmBilgiBolumDuzenle_Load);
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.panelOgrAra.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbBolKodu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox cbDuzenleBolDuzenle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbDuzenleBolSil;
        private System.Windows.Forms.TextBox txtDuzenleBolKodu;
        private System.Windows.Forms.ComboBox cboxDuzenleBolBaskani;
        private System.Windows.Forms.Button btnABolDuzenle;
        private System.Windows.Forms.Button btnBolAra;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.ComboBox cboxBolumBaskani;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAraBolAdi;
        private System.Windows.Forms.RadioButton rbAkaAdi;
        private System.Windows.Forms.TextBox txtAraBolKodu;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton rbBolAdi;
        private System.Windows.Forms.TextBox txtDuzenleBolAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.Button btnBolSil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label13;
    }
}