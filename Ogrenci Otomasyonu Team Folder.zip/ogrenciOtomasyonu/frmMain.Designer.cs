﻿namespace ogrenciOtomasyonu
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnAdminGiris = new System.Windows.Forms.Button();
            this.btnAkaGiris = new System.Windows.Forms.Button();
            this.btnOgrenciGiris = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAdminGiris
            // 
            this.btnAdminGiris.AutoEllipsis = true;
            this.btnAdminGiris.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAdminGiris.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.bilgi2;
            this.btnAdminGiris.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdminGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdminGiris.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAdminGiris.FlatAppearance.BorderSize = 5;
            this.btnAdminGiris.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAdminGiris.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAdminGiris.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdminGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAdminGiris.ForeColor = System.Drawing.Color.White;
            this.btnAdminGiris.Location = new System.Drawing.Point(582, 12);
            this.btnAdminGiris.Name = "btnAdminGiris";
            this.btnAdminGiris.Padding = new System.Windows.Forms.Padding(5);
            this.btnAdminGiris.Size = new System.Drawing.Size(279, 261);
            this.btnAdminGiris.TabIndex = 2;
            this.btnAdminGiris.Text = "Bilgi İşlem Sistemi";
            this.btnAdminGiris.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAdminGiris.UseCompatibleTextRendering = true;
            this.btnAdminGiris.UseVisualStyleBackColor = false;
            this.btnAdminGiris.Click += new System.EventHandler(this.btnAdminGiris_Click);
            // 
            // btnAkaGiris
            // 
            this.btnAkaGiris.AutoEllipsis = true;
            this.btnAkaGiris.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAkaGiris.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.akademisyen;
            this.btnAkaGiris.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAkaGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAkaGiris.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAkaGiris.FlatAppearance.BorderSize = 5;
            this.btnAkaGiris.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAkaGiris.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAkaGiris.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAkaGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAkaGiris.ForeColor = System.Drawing.Color.White;
            this.btnAkaGiris.Location = new System.Drawing.Point(297, 12);
            this.btnAkaGiris.Name = "btnAkaGiris";
            this.btnAkaGiris.Padding = new System.Windows.Forms.Padding(5);
            this.btnAkaGiris.Size = new System.Drawing.Size(279, 261);
            this.btnAkaGiris.TabIndex = 1;
            this.btnAkaGiris.Text = "Akademisyen Sistemi";
            this.btnAkaGiris.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAkaGiris.UseCompatibleTextRendering = true;
            this.btnAkaGiris.UseVisualStyleBackColor = false;
            this.btnAkaGiris.Click += new System.EventHandler(this.btnAkaGiris_Click);
            // 
            // btnOgrenciGiris
            // 
            this.btnOgrenciGiris.AutoEllipsis = true;
            this.btnOgrenciGiris.BackColor = System.Drawing.Color.SeaGreen;
            this.btnOgrenciGiris.BackgroundImage = global::ogrenciOtomasyonu.Properties.Resources.ogrenci;
            this.btnOgrenciGiris.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOgrenciGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOgrenciGiris.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnOgrenciGiris.FlatAppearance.BorderSize = 5;
            this.btnOgrenciGiris.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnOgrenciGiris.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnOgrenciGiris.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOgrenciGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciGiris.ForeColor = System.Drawing.Color.White;
            this.btnOgrenciGiris.Location = new System.Drawing.Point(12, 12);
            this.btnOgrenciGiris.Name = "btnOgrenciGiris";
            this.btnOgrenciGiris.Padding = new System.Windows.Forms.Padding(5);
            this.btnOgrenciGiris.Size = new System.Drawing.Size(279, 261);
            this.btnOgrenciGiris.TabIndex = 0;
            this.btnOgrenciGiris.Text = "Öğrenci Sistemi";
            this.btnOgrenciGiris.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOgrenciGiris.UseCompatibleTextRendering = true;
            this.btnOgrenciGiris.UseVisualStyleBackColor = false;
            this.btnOgrenciGiris.Click += new System.EventHandler(this.btnOgrenciGiris_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(873, 285);
            this.Controls.Add(this.btnAdminGiris);
            this.Controls.Add(this.btnAkaGiris);
            this.Controls.Add(this.btnOgrenciGiris);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Öğrenci Otomasyonu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOgrenciGiris;
        private System.Windows.Forms.Button btnAkaGiris;
        private System.Windows.Forms.Button btnAdminGiris;
    }
}

