﻿namespace ogrenciOtomasyonu
{
    partial class frmBilgiOgrDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilgiOgrDuzenle));
            this.panelOgrAra = new System.Windows.Forms.Panel();
            this.gboxOgrAra = new System.Windows.Forms.GroupBox();
            this.btnAra = new System.Windows.Forms.Button();
            this.rbOgrNo = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAraOgrSoyadi = new System.Windows.Forms.TextBox();
            this.rbOgrSoyadi = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAraOgrTC = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rbOgrAdi = new System.Windows.Forms.RadioButton();
            this.txtAraOgrNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAraOgrAdi = new System.Windows.Forms.TextBox();
            this.rbOgrTC = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panelOgrDuzenle = new System.Windows.Forms.Panel();
            this.gboxOgrDuzenle = new System.Windows.Forms.GroupBox();
            this.lblOgrNo = new System.Windows.Forms.Label();
            this.cbDuzenleOgrDuzenle = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDuzenleOgrSil = new System.Windows.Forms.CheckBox();
            this.txtDuzenleOgrGNO = new System.Windows.Forms.TextBox();
            this.txtDuzenleOgrTC = new System.Windows.Forms.TextBox();
            this.cboxDuzenleOgrBolum = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDuzenleOgrAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDuzenleOgrAdres = new System.Windows.Forms.TextBox();
            this.txtDuzenleOgrTel = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSil = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDuzenleOgrSoyadi = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panelOgrAra.SuspendLayout();
            this.gboxOgrAra.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelOgrDuzenle.SuspendLayout();
            this.gboxOgrDuzenle.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelOgrAra
            // 
            this.panelOgrAra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrAra.Controls.Add(this.gboxOgrAra);
            this.panelOgrAra.ForeColor = System.Drawing.Color.White;
            this.panelOgrAra.Location = new System.Drawing.Point(380, 57);
            this.panelOgrAra.Name = "panelOgrAra";
            this.panelOgrAra.Size = new System.Drawing.Size(393, 377);
            this.panelOgrAra.TabIndex = 10;
            // 
            // gboxOgrAra
            // 
            this.gboxOgrAra.Controls.Add(this.btnAra);
            this.gboxOgrAra.Controls.Add(this.rbOgrNo);
            this.gboxOgrAra.Controls.Add(this.label9);
            this.gboxOgrAra.Controls.Add(this.txtAraOgrSoyadi);
            this.gboxOgrAra.Controls.Add(this.rbOgrSoyadi);
            this.gboxOgrAra.Controls.Add(this.label1);
            this.gboxOgrAra.Controls.Add(this.txtAraOgrTC);
            this.gboxOgrAra.Controls.Add(this.label11);
            this.gboxOgrAra.Controls.Add(this.rbOgrAdi);
            this.gboxOgrAra.Controls.Add(this.txtAraOgrNo);
            this.gboxOgrAra.Controls.Add(this.label10);
            this.gboxOgrAra.Controls.Add(this.txtAraOgrAdi);
            this.gboxOgrAra.Controls.Add(this.rbOgrTC);
            this.gboxOgrAra.ForeColor = System.Drawing.Color.White;
            this.gboxOgrAra.Location = new System.Drawing.Point(3, 1);
            this.gboxOgrAra.Name = "gboxOgrAra";
            this.gboxOgrAra.Size = new System.Drawing.Size(385, 372);
            this.gboxOgrAra.TabIndex = 12;
            this.gboxOgrAra.TabStop = false;
            this.gboxOgrAra.Text = "Öğrenci Arama";
            // 
            // btnAra
            // 
            this.btnAra.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAra.ForeColor = System.Drawing.Color.White;
            this.btnAra.Location = new System.Drawing.Point(126, 152);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(220, 50);
            this.btnAra.TabIndex = 6;
            this.btnAra.Text = "ARA";
            this.btnAra.UseVisualStyleBackColor = false;
            this.btnAra.Click += new System.EventHandler(this.button2_Click);
            // 
            // rbOgrNo
            // 
            this.rbOgrNo.AutoSize = true;
            this.rbOgrNo.Location = new System.Drawing.Point(18, 20);
            this.rbOgrNo.Name = "rbOgrNo";
            this.rbOgrNo.Size = new System.Drawing.Size(79, 17);
            this.rbOgrNo.TabIndex = 1;
            this.rbOgrNo.TabStop = true;
            this.rbOgrNo.Text = "Öğrenci No";
            this.rbOgrNo.UseVisualStyleBackColor = true;
            this.rbOgrNo.CheckedChanged += new System.EventHandler(this.rbOgrNo_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(57, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Öğrenci TC : ";
            // 
            // txtAraOgrSoyadi
            // 
            this.txtAraOgrSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraOgrSoyadi.Location = new System.Drawing.Point(126, 126);
            this.txtAraOgrSoyadi.Name = "txtAraOgrSoyadi";
            this.txtAraOgrSoyadi.Size = new System.Drawing.Size(220, 20);
            this.txtAraOgrSoyadi.TabIndex = 5;
            // 
            // rbOgrSoyadi
            // 
            this.rbOgrSoyadi.AutoSize = true;
            this.rbOgrSoyadi.Location = new System.Drawing.Point(274, 20);
            this.rbOgrSoyadi.Name = "rbOgrSoyadi";
            this.rbOgrSoyadi.Size = new System.Drawing.Size(97, 17);
            this.rbOgrSoyadi.TabIndex = 4;
            this.rbOgrSoyadi.TabStop = true;
            this.rbOgrSoyadi.Text = "Öğrenci Soyadi";
            this.rbOgrSoyadi.UseVisualStyleBackColor = true;
            this.rbOgrSoyadi.CheckedChanged += new System.EventHandler(this.rbOgrSoyadi_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Öğrenci No : ";
            // 
            // txtAraOgrTC
            // 
            this.txtAraOgrTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraOgrTC.Location = new System.Drawing.Point(126, 74);
            this.txtAraOgrTC.Name = "txtAraOgrTC";
            this.txtAraOgrTC.Size = new System.Drawing.Size(220, 20);
            this.txtAraOgrTC.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Öğrenci Soyadi : ";
            // 
            // rbOgrAdi
            // 
            this.rbOgrAdi.AutoSize = true;
            this.rbOgrAdi.Location = new System.Drawing.Point(188, 19);
            this.rbOgrAdi.Name = "rbOgrAdi";
            this.rbOgrAdi.Size = new System.Drawing.Size(80, 17);
            this.rbOgrAdi.TabIndex = 3;
            this.rbOgrAdi.TabStop = true;
            this.rbOgrAdi.Text = "Öğrenci Adi";
            this.rbOgrAdi.UseVisualStyleBackColor = true;
            this.rbOgrAdi.CheckedChanged += new System.EventHandler(this.rbOgrAdi_CheckedChanged);
            // 
            // txtAraOgrNo
            // 
            this.txtAraOgrNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraOgrNo.Location = new System.Drawing.Point(126, 48);
            this.txtAraOgrNo.Name = "txtAraOgrNo";
            this.txtAraOgrNo.Size = new System.Drawing.Size(220, 20);
            this.txtAraOgrNo.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(56, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Öğrenci Adi : ";
            // 
            // txtAraOgrAdi
            // 
            this.txtAraOgrAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAraOgrAdi.Location = new System.Drawing.Point(126, 100);
            this.txtAraOgrAdi.Name = "txtAraOgrAdi";
            this.txtAraOgrAdi.Size = new System.Drawing.Size(220, 20);
            this.txtAraOgrAdi.TabIndex = 5;
            // 
            // rbOgrTC
            // 
            this.rbOgrTC.AutoSize = true;
            this.rbOgrTC.Location = new System.Drawing.Point(103, 20);
            this.rbOgrTC.Name = "rbOgrTC";
            this.rbOgrTC.Size = new System.Drawing.Size(79, 17);
            this.rbOgrTC.TabIndex = 2;
            this.rbOgrTC.TabStop = true;
            this.rbOgrTC.Text = "Öğrenci TC";
            this.rbOgrTC.UseVisualStyleBackColor = true;
            this.rbOgrTC.CheckedChanged += new System.EventHandler(this.rbOgrTC_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label12);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(362, 38);
            this.panel1.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Brown;
            this.label12.Location = new System.Drawing.Point(81, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(207, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Öğrenci Düzenle Bölümü";
            // 
            // panelOgrDuzenle
            // 
            this.panelOgrDuzenle.BackColor = System.Drawing.Color.SteelBlue;
            this.panelOgrDuzenle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelOgrDuzenle.Controls.Add(this.gboxOgrDuzenle);
            this.panelOgrDuzenle.Enabled = false;
            this.panelOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.panelOgrDuzenle.Location = new System.Drawing.Point(12, 56);
            this.panelOgrDuzenle.Name = "panelOgrDuzenle";
            this.panelOgrDuzenle.Size = new System.Drawing.Size(362, 378);
            this.panelOgrDuzenle.TabIndex = 8;
            // 
            // gboxOgrDuzenle
            // 
            this.gboxOgrDuzenle.Controls.Add(this.lblOgrNo);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleOgrDuzenle);
            this.gboxOgrDuzenle.Controls.Add(this.label14);
            this.gboxOgrDuzenle.Controls.Add(this.label2);
            this.gboxOgrDuzenle.Controls.Add(this.label4);
            this.gboxOgrDuzenle.Controls.Add(this.cbDuzenleOgrSil);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrGNO);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrTC);
            this.gboxOgrDuzenle.Controls.Add(this.cboxDuzenleOgrBolum);
            this.gboxOgrDuzenle.Controls.Add(this.button1);
            this.gboxOgrDuzenle.Controls.Add(this.label5);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrAdi);
            this.gboxOgrDuzenle.Controls.Add(this.label3);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrAdres);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrTel);
            this.gboxOgrDuzenle.Controls.Add(this.label7);
            this.gboxOgrDuzenle.Controls.Add(this.btnSil);
            this.gboxOgrDuzenle.Controls.Add(this.label8);
            this.gboxOgrDuzenle.Controls.Add(this.label6);
            this.gboxOgrDuzenle.Controls.Add(this.txtDuzenleOgrSoyadi);
            this.gboxOgrDuzenle.ForeColor = System.Drawing.Color.White;
            this.gboxOgrDuzenle.Location = new System.Drawing.Point(3, 2);
            this.gboxOgrDuzenle.Name = "gboxOgrDuzenle";
            this.gboxOgrDuzenle.Size = new System.Drawing.Size(354, 372);
            this.gboxOgrDuzenle.TabIndex = 12;
            this.gboxOgrDuzenle.TabStop = false;
            this.gboxOgrDuzenle.Text = "Öğrenci Düzenle";
            // 
            // lblOgrNo
            // 
            this.lblOgrNo.AutoSize = true;
            this.lblOgrNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOgrNo.Location = new System.Drawing.Point(109, 32);
            this.lblOgrNo.Name = "lblOgrNo";
            this.lblOgrNo.Size = new System.Drawing.Size(0, 15);
            this.lblOgrNo.TabIndex = 11;
            // 
            // cbDuzenleOgrDuzenle
            // 
            this.cbDuzenleOgrDuzenle.AutoSize = true;
            this.cbDuzenleOgrDuzenle.Location = new System.Drawing.Point(202, 287);
            this.cbDuzenleOgrDuzenle.Name = "cbDuzenleOgrDuzenle";
            this.cbDuzenleOgrDuzenle.Size = new System.Drawing.Size(112, 17);
            this.cbDuzenleOgrDuzenle.TabIndex = 8;
            this.cbDuzenleOgrDuzenle.Text = "Öğrenciyi Düzenle";
            this.cbDuzenleOgrDuzenle.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 34);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Öğrenci No : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Öğrenci TC : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Öğrenci Soyadi : ";
            // 
            // cbDuzenleOgrSil
            // 
            this.cbDuzenleOgrSil.AutoSize = true;
            this.cbDuzenleOgrSil.Location = new System.Drawing.Point(112, 287);
            this.cbDuzenleOgrSil.Name = "cbDuzenleOgrSil";
            this.cbDuzenleOgrSil.Size = new System.Drawing.Size(84, 17);
            this.cbDuzenleOgrSil.TabIndex = 7;
            this.cbDuzenleOgrSil.Text = "Öğrenciyi Sil";
            this.cbDuzenleOgrSil.UseVisualStyleBackColor = true;
            // 
            // txtDuzenleOgrGNO
            // 
            this.txtDuzenleOgrGNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrGNO.Enabled = false;
            this.txtDuzenleOgrGNO.Location = new System.Drawing.Point(112, 261);
            this.txtDuzenleOgrGNO.Name = "txtDuzenleOgrGNO";
            this.txtDuzenleOgrGNO.Size = new System.Drawing.Size(76, 20);
            this.txtDuzenleOgrGNO.TabIndex = 7;
            // 
            // txtDuzenleOgrTC
            // 
            this.txtDuzenleOgrTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrTC.Location = new System.Drawing.Point(112, 51);
            this.txtDuzenleOgrTC.Name = "txtDuzenleOgrTC";
            this.txtDuzenleOgrTC.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleOgrTC.TabIndex = 1;
            // 
            // cboxDuzenleOgrBolum
            // 
            this.cboxDuzenleOgrBolum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDuzenleOgrBolum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxDuzenleOgrBolum.FormattingEnabled = true;
            this.cboxDuzenleOgrBolum.Location = new System.Drawing.Point(112, 234);
            this.cboxDuzenleOgrBolum.Name = "cboxDuzenleOgrBolum";
            this.cboxDuzenleOgrBolum.Size = new System.Drawing.Size(220, 21);
            this.cboxDuzenleOgrBolum.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Highlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(179, 310);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 50);
            this.button1.TabIndex = 9;
            this.button1.Text = "DÜZENLE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Öğrenci Telefon : ";
            // 
            // txtDuzenleOgrAdi
            // 
            this.txtDuzenleOgrAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrAdi.Location = new System.Drawing.Point(112, 77);
            this.txtDuzenleOgrAdi.Name = "txtDuzenleOgrAdi";
            this.txtDuzenleOgrAdi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleOgrAdi.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Öğrenci Adi : ";
            // 
            // txtDuzenleOgrAdres
            // 
            this.txtDuzenleOgrAdres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrAdres.Location = new System.Drawing.Point(112, 155);
            this.txtDuzenleOgrAdres.Multiline = true;
            this.txtDuzenleOgrAdres.Name = "txtDuzenleOgrAdres";
            this.txtDuzenleOgrAdres.Size = new System.Drawing.Size(220, 73);
            this.txtDuzenleOgrAdres.TabIndex = 5;
            // 
            // txtDuzenleOgrTel
            // 
            this.txtDuzenleOgrTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrTel.Location = new System.Drawing.Point(112, 129);
            this.txtDuzenleOgrTel.Name = "txtDuzenleOgrTel";
            this.txtDuzenleOgrTel.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleOgrTel.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 264);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Öğrenci GNO : ";
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.Maroon;
            this.btnSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSil.ForeColor = System.Drawing.Color.White;
            this.btnSil.Location = new System.Drawing.Point(7, 310);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(166, 50);
            this.btnSil.TabIndex = 10;
            this.btnSil.Text = "SİL";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Öğrenci Adres: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Öğrenci Bölümü : ";
            // 
            // txtDuzenleOgrSoyadi
            // 
            this.txtDuzenleOgrSoyadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDuzenleOgrSoyadi.Location = new System.Drawing.Point(112, 103);
            this.txtDuzenleOgrSoyadi.Name = "txtDuzenleOgrSoyadi";
            this.txtDuzenleOgrSoyadi.Size = new System.Drawing.Size(220, 20);
            this.txtDuzenleOgrSoyadi.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label13);
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(380, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(393, 38);
            this.panel2.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Brown;
            this.label13.Location = new System.Drawing.Point(95, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(193, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "Öğrenci Arama Bölümü";
            // 
            // frmBilgiOgrDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(786, 448);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelOgrAra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelOgrDuzenle);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBilgiOgrDuzenle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Öğrenci Düzenle";
            this.Load += new System.EventHandler(this.frmOgrDuzenle_Load);
            this.panelOgrAra.ResumeLayout(false);
            this.gboxOgrAra.ResumeLayout(false);
            this.gboxOgrAra.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.ResumeLayout(false);
            this.gboxOgrDuzenle.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelOgrAra;
        private System.Windows.Forms.Button btnAra;
        private System.Windows.Forms.RadioButton rbOgrNo;
        private System.Windows.Forms.TextBox txtAraOgrSoyadi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtAraOgrNo;
        private System.Windows.Forms.TextBox txtAraOgrAdi;
        private System.Windows.Forms.RadioButton rbOgrTC;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton rbOgrAdi;
        private System.Windows.Forms.TextBox txtAraOgrTC;
        private System.Windows.Forms.RadioButton rbOgrSoyadi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelOgrDuzenle;
        private System.Windows.Forms.CheckBox cbDuzenleOgrDuzenle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbDuzenleOgrSil;
        private System.Windows.Forms.TextBox txtDuzenleOgrTC;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtDuzenleOgrAdi;
        private System.Windows.Forms.TextBox txtDuzenleOgrAdres;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDuzenleOgrSoyadi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.TextBox txtDuzenleOgrTel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboxDuzenleOgrBolum;
        private System.Windows.Forms.TextBox txtDuzenleOgrGNO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox gboxOgrAra;
        private System.Windows.Forms.GroupBox gboxOgrDuzenle;
        private System.Windows.Forms.Label lblOgrNo;
        private System.Windows.Forms.Label label14;

    }
}